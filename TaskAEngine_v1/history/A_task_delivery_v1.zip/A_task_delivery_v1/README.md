# A 任务预测包

默认使用稳定 MLP。候选供明确指定后评估。

```sh
python predict.py --verify
python predict.py < requests.jsonl
python predict.py --variant fusion < requests.jsonl
python predict.py --variant witness_veto < requests.jsonl
python predict.py --variant projected_support < requests.jsonl
python review.py --output decision.json
```

每行输入包含 inputs.features，共 128 个有限数值。可附 task=classification。输出六类 label/score。包内包含 NumPy 模型和预测代码。新候选只有 Batch 1 内部压力测试，独立泛化待验证。review.py 支持无更新决策，评估需显式提供 --variant、--train、--evaluation。合法独立评估须同时声明 --evidence independent_released 与 --release-id。该声明由调用方负责核实，评审输出晋升建议，实际生效模型由 manifest 中 active_variant 决定。Linux 运行尚待赛事容器实测，Python/NumPy 依赖应按正式环境安装。
