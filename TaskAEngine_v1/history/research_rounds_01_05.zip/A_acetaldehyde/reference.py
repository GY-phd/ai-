"""Test reference-resistance compensation with source-only temporal checks."""

import argparse
import json
from pathlib import Path
import sys
from time import perf_counter, process_time

import experiment as ex
import rescue
from experiment import CLASSES, INCUMBENT, PUBLIC, SOURCE
from experiment import Model, checkpoint_digest, format_prediction, json_value, np, read_dataset, score
from rollout import review


VIEWS = ("relative_steady", "reference_ema", "reference_and_shape", "relative_and_rise", "type_shape")
BLENDS = (0.6, 0.85, 1.0)
SEEDS = (42, 73, 131)
VERSION = "a.reference-response.v1"


def centered(x):
    return x - np.median(x, axis=1, keepdims=True)


def features(x, view):
    s = x.reshape(-1, 16, 8)
    relative = s[:, :, 1:2] - 1
    relative_log = np.log(np.maximum(np.abs(relative), 1e-6))
    log_ema = np.log(np.maximum(np.abs(s[:, :, 2:]), 1e-3))
    valid_ref = (np.abs(relative) > 1e-6) & (np.abs(s[:, :, :1]) > 1e-3)
    log_ref = np.log(np.maximum(np.abs(s[:, :, :1]), 1e-3)) - relative_log
    # ΔR / (ratio - 1) estimates R_ref. (0, 1) contains no reference information.
    log_ref = np.where(valid_ref, log_ref, np.log(1e4))
    ema_over_ref = log_ema - log_ref
    rise_shape = log_ema[:, :, 1:3] - log_ema[:, :, :1]
    relative_shape = centered(relative_log)
    if view == "relative_steady":
        values = (relative_shape,)
    elif view == "reference_ema":
        values = (relative_shape, centered(ema_over_ref))
    elif view == "reference_and_shape":
        values = (relative_shape, centered(ema_over_ref[:, :, :3]), rise_shape)
    elif view == "relative_and_rise":
        values = (relative_shape, rise_shape)
    else:
        values = (centered(relative_log), rescue.within_type(ema_over_ref[:, :, :3]),
                  np.stack([rise_shape[:, rescue.GROUP == i].mean(axis=1) for i in range(4)], axis=1))
    return np.concatenate([array.reshape(len(x), -1) for array in values], axis=1)


def fit(x, y, view):
    shifted = [rescue.stress(x, case, seed) for seed in (11, 29, 61) for case in rescue.CASES[1:]]
    z = features(np.concatenate([x, x, *shifted]), view)
    median = np.median(z, axis=0)
    low, high = np.percentile(z, (25, 75), axis=0)
    scale = np.maximum(high - low, 0.05)
    design = rescue.design_matrix(z, median, scale)
    weights = np.tile(np.sqrt(len(y) / (len(CLASSES) * np.bincount(y)[y])), len(shifted) + 2)
    target = np.tile(np.eye(len(CLASSES))[y], (len(shifted) + 2, 1))
    weighted = design * weights[:, None]
    penalty = np.eye(design.shape[1]) * 2 * (len(shifted) + 2)
    penalty[0, 0] = 0
    coef = np.linalg.solve(weighted.T @ weighted + penalty, weighted.T @ (target * weights[:, None]))
    return median, scale, coef


class Reference:
    def __init__(self, parent, view, blend, state):
        self.parent, self.meta = parent, parent.meta
        self.view, self.blend, self.state = view, blend, state

    def auxiliary(self, x):
        median, scale, coef = self.state
        return ex.softmax(6 * (rescue.design_matrix(features(x, self.view), median, scale) @ coef))

    def predict(self, x):
        return (1 - self.blend) * self.parent.predict(x) + self.blend * self.auxiliary(x)

    @classmethod
    def load(cls, path, parent_path):
        parent = Model.load(parent_path)
        with np.load(path, allow_pickle=False) as state:
            view, blend = str(state["view"]), float(state["blend"])
            if (str(state["version"]) != VERSION or str(state["parent_digest"]) != checkpoint_digest(parent_path)
                    or view not in VIEWS or blend not in BLENDS):
                raise ValueError("invalid reference model or parent digest mismatch")
            return cls(parent, view, blend, (state["median"], state["scale"], state["coef"]))


def source_selection(train):
    x, y = train["x"], train["y"]
    assignment, groups = ex.source_folds(x, y)
    # The supplied Batch 1 row order matches the original paper's first two month blocks.
    expected = np.repeat([0, 1, 2, 0, 1, 2, 3, 4, 5], [84, 88, 76, 6, 10, 7, 30, 70, 74])
    if not np.array_equal(y, expected):
        raise ValueError("month guard requires the original Batch 1 row order")
    month_two = np.arange(len(y)) >= 248
    configs = [(view, blend) for view in VIEWS for blend in BLENDS]
    records = {config: [] for config in configs}
    splits = (("group_0", assignment == 0), ("group_1", assignment == 1), ("month_1", ~month_two))
    for split, test in splits:
        states = {view: fit(x[~test], y[~test], view) for view in VIEWS}
        for seed in SEEDS:
            parent = ex.source_control(train, ~test, seed)
            for case in (("clean",) if split == "month_1" else rescue.CASES):
                sample = rescue.stress(x[test], case, seed)
                original = parent.predict(sample)
                for view, state in states.items():
                    probabilities = Reference(parent, view, 1., state).auxiliary(sample)
                    for blend in BLENDS:
                        measured = score(y[test], (1 - blend) * original + blend * probabilities)
                        records[view, blend].append({"split": split, "seed": seed, "case": case, "metrics": measured})

    def summarize(config, runs):
        folds = [r["metrics"] for r in runs if r["split"] != "month_1"]
        month = [r["metrics"] for r in runs if r["split"] == "month_1"]
        macro = float(np.mean([m["macro_f1"] for m in folds]))
        acetaldehyde = float(np.mean([m["per_class"]["Acetaldehyde"]["f1"] for m in folds]))
        ethanol = float(np.mean([m["per_class"]["Ethanol"]["recall"] for m in month]))
        false_alarm = float(np.mean([m["per_class"]["Acetaldehyde"]["predicted"] / 248 for m in month]))
        utility = 0.35 * macro + 0.35 * acetaldehyde + 0.3 * ethanol - false_alarm
        return {"view": config[0], "blend": config[1], "utility": utility, "group_macro_f1": macro,
                "group_acetaldehyde_f1": acetaldehyde, "cross_month_ethanol_recall": ethanol,
                "cross_month_acetaldehyde_false_alarm": false_alarm, "runs": runs}

    ranking = sorted((summarize(config, records[config]) for config in configs), key=lambda r: r["utility"], reverse=True)
    return {k: v for k, v in ranking[0].items() if k != "runs"}, ranking, groups


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("select", "evaluate", "predict"))
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--parent", default=INCUMBENT, type=Path)
    args = parser.parse_args()
    checkpoint = args.run / "reference.npz"
    code = {**rescue.code_digests(), "reference.py": checkpoint_digest(Path(__file__))}
    if args.action == "predict":
        model = Reference.load(checkpoint, args.parent)
        for line in sys.stdin:
            if line.strip():
                request = json_value(line)
                if not isinstance(request, dict) or set(request) - {"task", "inputs"} or "inputs" not in request:
                    raise ValueError("prediction request requires only task and inputs")
                if request.get("task", "classification") != "classification":
                    raise ValueError("prediction task mismatch")
                print(json.dumps(format_prediction(model, request["inputs"]), allow_nan=False), flush=True)
        return
    parent = Model.load(args.parent)
    train = read_dataset(SOURCE, "classification", CLASSES, parent.meta["paths"])
    selection_path = args.run / "selection.json"
    if args.action == "select":
        start, cpu_start = perf_counter(), process_time()
        selected, ranking, groups = source_selection(train)
        fit_start = perf_counter()
        median, scale, coef = fit(train["x"], train["y"], selected["view"])
        fit_seconds = perf_counter() - fit_start
        args.run.mkdir(parents=True, exist_ok=False)
        parent_digest = checkpoint_digest(args.parent)
        with checkpoint.open("xb") as output:
            np.savez_compressed(output, version=VERSION, parent_digest=parent_digest, view=selected["view"],
                                blend=selected["blend"], median=median, scale=scale, coef=coef)
        ex.save_json(selection_path, {"format": VERSION, "experiment_id": args.run.name, "selected": selected,
                                     "train_rows": len(train["y"]), "train_sha256": train["sha256"],
                                     "candidate_sha256": checkpoint_digest(checkpoint), "parent_checkpoint_sha256": parent_digest,
                                     "code_sha256": code, "ranking": ranking, "groups": groups, "seeds": SEEDS,
                                     "cases": rescue.CASES, "fit_seconds": fit_seconds, "selection_seconds": perf_counter() - start,
                                     "selection_cpu_seconds": process_time() - cpu_start, "llm_calls": 0})
        print(json.dumps(selected))
        return
    output = args.run / "public_evaluation.json"
    if output.exists():
        raise FileExistsError(output)
    selection = json.loads(selection_path.read_text(encoding="utf-8"))
    if (selection["candidate_sha256"] != checkpoint_digest(checkpoint) or selection["code_sha256"] != code
            or selection["train_sha256"] != train["sha256"]):
        raise ValueError("checkpoint, code or training data changed after selection")
    model = Reference.load(checkpoint, args.parent)
    data = read_dataset(PUBLIC, "classification", CLASSES, parent.meta["paths"])
    if set(train["ids"]) & set(data["ids"]) or set(map(tuple, train["x"])) & set(map(tuple, data["x"])):
        raise ValueError("training and evaluation overlap")
    metrics = {}
    for key, estimator in (("original", Model.load(ex.ORIGINAL)), ("incumbent", parent), ("candidate", model)):
        start = perf_counter()
        probabilities = estimator.predict(data["x"])
        metrics[key] = score(data["y"], probabilities)
        metrics[key]["batch_prediction_seconds"] = perf_counter() - start
    result = {"format": VERSION, "experiment_id": args.run.name, "selected": selection["selected"], "classes": CLASSES,
              "candidate_sha256": selection["candidate_sha256"], "evaluation_sha256": data["sha256"],
              "evaluation_rows": len(data["y"]), "metrics": metrics, "rollout": review(metrics["incumbent"], metrics["candidate"])}
    ex.save_json(output, result)
    print(json.dumps({"macro_f1": {name: m["macro_f1"] for name, m in metrics.items()},
                      "acetaldehyde": metrics["candidate"]["per_class"]["Acetaldehyde"], "rollout": result["rollout"]}))


if __name__ == "__main__":
    main()
