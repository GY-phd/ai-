"""Export a standalone NumPy predictor with original MLP and research candidates."""

import argparse
import ast
import inspect
import json
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory
import zipfile

import routing
from routing import a, ex


class GroupReference(ast.NodeTransformer):
    def visit_Attribute(self, node):
        if isinstance(node.value, ast.Name) and node.value.id == "rescue" and node.attr == "GROUP":
            return ast.copy_location(ast.Name(id="GROUP", ctx=ast.Load()), node)
        return self.generic_visit(node)


def feature_source():
    definitions = []
    for path, names in ((Path(ex.__file__), ("transform", "softmax", "score")), (Path(a.__file__), ("project",))):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name in names:
                definitions.append(ast.unparse(GroupReference().visit(node)))
    return ('"""Generated from the tested experiment feature functions."""\nimport numpy as np\n'
            'GROUP = np.tile(np.repeat(np.arange(4), 2), 2)\nCLASSES = ' + repr(ex.CLASSES) + '\n\n' + "\n\n".join(definitions) + "\n")


def export(args):
    archive = args.output.with_suffix(".zip")
    if args.output.exists() or archive.exists():
        raise FileExistsError("bundle folder and archive must be new")
    receipt = a.read_receipt(args.receipt, args.fusion, args.incumbent)
    fusion = a.load_fusion(args.fusion, args.incumbent)
    report = ex.json_value(args.study.read_text(encoding="utf-8"))
    expected_code = {**a.implementation_digests(), "routing.py": ex.checkpoint_digest(Path(routing.__file__))}
    expected_receipts = {key: receipt[key] for key in ("train_sha256", "candidate_sha256", "parent_checkpoint_sha256")}
    if (report["version"] != routing.VERSION or report["receipts"] != expected_receipts
            or report["code_sha256"] != expected_code or report["state_sha256"] != ex.checkpoint_digest(args.state)):
        raise ValueError("study, state, source code and parent model must match")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".bundle-", dir=args.output.parent) as temporary:
        folder = Path(temporary) / "bundle"
        (folder / "baselines").mkdir(parents=True)
        (folder / "models").mkdir()
        baseline_dir = Path(inspect.getfile(ex.Model)).parent
        for name in ("__init__.py", "model.py", "data.py", "predict.py"):
            shutil.copyfile(baseline_dir / name, folder / "baselines" / name)
        shutil.copyfile(Path(__file__).with_name("bundle_predict.py"), folder / "predict.py")
        shutil.copyfile(Path(__file__).with_name("bundle_review.py"), folder / "review.py")
        for name in ("decision.py", "rollout.py"):
            shutil.copyfile(Path(__file__).with_name(name), folder / name)
        (folder / "feature_ops.py").write_text(feature_source(), encoding="utf-8")
        for source, name in ((args.incumbent, "stable.npz"), (args.fusion, "fusion.npz"), (args.state, "routing.npz")):
            shutil.copyfile(source, folder / "models" / name)
        (folder / "requirements.txt").write_text("numpy>=1.26.4,<3\n", encoding="utf-8")
        (folder / "README.md").write_text(
            "# A 任务预测包\n\n默认使用稳定 MLP。候选供明确指定后评估。\n\n"
            "```sh\npython predict.py --verify\npython predict.py < requests.jsonl\n"
            "python predict.py --variant fusion < requests.jsonl\n"
            "python predict.py --variant witness_veto < requests.jsonl\n"
            "python predict.py --variant projected_support < requests.jsonl\n"
            "python review.py --output decision.json\n```\n\n"
            "每行输入包含 inputs.features，共 128 个有限数值。可附 task=classification。输出六类 label/score。"
            "包内包含 NumPy 模型和预测代码。新候选只有 Batch 1 内部压力测试，独立泛化待验证。"
            "review.py 支持无更新决策，评估需显式提供 --variant、--train、--evaluation。"
            "合法独立评估须同时声明 --evidence independent_released 与 --release-id。"
            "该声明由调用方负责核实，评审输出晋升建议，实际生效模型由 manifest 中 active_variant 决定。"
            "Linux 运行尚待赛事容器实测，Python/NumPy 依赖应按正式环境安装。\n", encoding="utf-8")
        manifest = {"format": "a.portable-bundle.v1", "active_variant": "stable", "variants": routing.VARIANTS,
                    "classes": fusion.meta["classes"], "incumbent": "models/stable.npz", "fusion": "models/fusion.npz",
                    "routing_state": "models/routing.npz", "training_receipts": expected_receipts,
                    "source_sha256": {**expected_code, "bundle_predict.py": ex.checkpoint_digest(Path(__file__).with_name("bundle_predict.py")),
                                       "bundle_review.py": ex.checkpoint_digest(Path(__file__).with_name("bundle_review.py")),
                                       "export_bundle.py": ex.checkpoint_digest(Path(__file__))},
                    "agent_summary": report["agent_summary"],
                    "files": {str(path.relative_to(folder)).replace("\\", "/"): ex.checkpoint_digest(path)
                              for path in sorted(folder.rglob("*")) if path.is_file()}}
        ex.save_json(folder / "manifest.json", manifest)
        staged_archive = Path(temporary) / "bundle.zip"
        with zipfile.ZipFile(staged_archive, "w", zipfile.ZIP_DEFLATED) as stream:
            for path in sorted(folder.rglob("*")):
                if path.is_file():
                    info = zipfile.ZipInfo(args.output.name + "/" + path.relative_to(folder).as_posix(), (2026, 11, 14, 0, 0, 0))
                    info.compress_type = zipfile.ZIP_DEFLATED
                    stream.writestr(info, path.read_bytes())
        if args.output.exists() or archive.exists():
            raise FileExistsError("bundle output appeared during export")
        folder.rename(args.output)
        staged_archive.rename(archive)
    print(json.dumps({"bundle": str(args.output), "zip": str(archive), "active_variant": "stable"}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("incumbent", "fusion", "receipt", "study", "state", "output"):
        parser.add_argument(f"--{name}", required=True, type=Path)
    export(parser.parse_args())


if __name__ == "__main__":
    main()
