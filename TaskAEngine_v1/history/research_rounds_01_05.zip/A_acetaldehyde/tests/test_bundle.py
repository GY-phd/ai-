"""Check relocated inference against the original implementation and corruption handling."""

import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
import routing
from routing import a, ex, np


class PortableTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bundle = HERE / "A_task_delivery_v1"
        cls.study_folder = HERE / "round_05"
        sys.path.insert(0, str(cls.bundle))
        spec = importlib.util.spec_from_file_location("portable_runtime", cls.bundle / "predict.py")
        cls.runtime = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.runtime)
        cls.fusion = a.load_fusion(HERE / "round_01" / "candidate.npz", ex.INCUMBENT)
        cls.data = ex.read_dataset(ex.SOURCE, "classification", ex.CLASSES, cls.fusion.meta["paths"])
        with np.load(cls.study_folder / "routing_state.npz", allow_pickle=False) as state:
            cls.detectors = {mode: tuple(state[f"{mode}_{field}"] for field in ("center", "scale", "basis", "cutoff"))
                             for mode in routing.VARIANTS[-2:]}
            cls.witness = tuple(state[f"witness_{field}"] for field in ("center", "scale", "coef"))

    def test_exported_predictions_match_reference(self):
        models = a.Models(self.fusion, {"witness_veto": self.witness})
        x = np.concatenate([self.data["x"], a.stress(self.data["x"], "channel_rate", 4001)])
        expected, flags = routing.predict_all(models, self.detectors, x)
        self.assertTrue(flags["projected_support"].any())
        for mode in routing.VARIANTS:
            predictor = self.runtime.Predictor(self.bundle / "manifest.json", mode)
            np.testing.assert_array_equal(predictor.predict(x), expected[mode])
            np.testing.assert_allclose(predictor.predict(x[:3]), np.vstack([predictor.predict(row[None, :]) for row in x[:3]]), atol=1e-12)

    def test_relocated_default_and_corruption(self):
        with TemporaryDirectory(prefix=".bundle-test-", dir=HERE) as temporary:
            destination = Path(temporary) / "portable"
            shutil.copytree(self.bundle, destination)
            command = [sys.executable, "-B", str(destination / "predict.py")]
            output = subprocess.run(command + ["--verify"], cwd=destination, check=True, capture_output=True, text=True)
            self.assertEqual(json.loads(output.stdout)["variant"], "stable")
            decision = subprocess.run([sys.executable, "-B", str(destination / "review.py"), "--output", "decision.json"],
                                      cwd=destination, check=True, capture_output=True, text=True)
            self.assertEqual(json.loads(decision.stdout)["decision"], "keep")
            row = {"inputs": {"features": self.data["x"][0].tolist()}}
            predicted = subprocess.run(command, input=json.dumps(row) + "\n", cwd=destination, check=True, capture_output=True, text=True)
            self.assertEqual(len(json.loads(predicted.stdout)["outputs"]), 6)
            checkpoint = destination / "models" / "routing.npz"
            checkpoint.write_bytes(checkpoint.read_bytes() + b"corrupted")
            failure = subprocess.run(command + ["--verify"], cwd=destination, capture_output=True, text=True)
            self.assertNotEqual(failure.returncode, 0)
            self.assertIn("integrity check", failure.stderr)


if __name__ == "__main__":
    unittest.main()
