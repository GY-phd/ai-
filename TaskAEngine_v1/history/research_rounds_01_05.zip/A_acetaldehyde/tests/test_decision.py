"""Test the Task A Harness decision contract with paired synthetic metrics."""

from copy import deepcopy
import json
import unittest

from A_acetaldehyde import decision


class DecisionTests(unittest.TestCase):
    def setUp(self):
        self.incumbent = {
            "macro_f1": 0.725,
            "accuracy": 0.88,
            "per_class": {
                label: {"support": 20, "precision": 0.8, "recall": 0.9, "f1": 0.85}
                for label in decision.rollout.CLASSES
            },
        }
        self.incumbent["per_class"]["Acetaldehyde"].update(precision=0.0, recall=0.0, f1=0.0)
        self.improved = deepcopy(self.incumbent)
        self.improved.update(macro_f1=0.8, accuracy=0.92)
        self.improved["per_class"]["Acetaldehyde"].update(precision=0.75, recall=0.8, f1=0.77)

    def test_no_candidate_or_no_metrics_keeps_incumbent(self):
        for candidates, reason in (({}, "no_candidate"), ({"fusion": None}, "missing_paired_evaluation")):
            with self.subTest(candidates=candidates):
                result = decision.assess(self.incumbent, candidates, evidence="unavailable")
                self.assertEqual(result["decision"], "keep")
                self.assertEqual(result["reason"], reason)
                self.assertIsNone(result["selected_candidate"])

    def test_source_and_public_evidence_cannot_promote(self):
        for evidence in ("source_holdout", "public_development"):
            with self.subTest(evidence=evidence):
                result = decision.assess(self.incumbent, {"fusion": self.improved}, evidence=evidence)
                self.assertEqual(result["decision"], "keep")
                self.assertEqual(result["reason"], "independent_evaluation_required")
                self.assertEqual(result["best_safe_candidate"], "fusion")
                self.assertIsNone(result["selected_candidate"])

    def test_highest_score_can_fail_guardrail(self):
        unsafe = deepcopy(self.improved)
        unsafe["macro_f1"] = 0.9
        unsafe["per_class"]["Ethanol"]["recall"] = 0.55
        result = decision.assess(self.incumbent, {"fusion": unsafe, "guarded": self.improved},
                                 evidence="independent_released")
        self.assertEqual(result["competition"]["main_metric"], "macro_f1")
        self.assertEqual(result["competition"]["candidates"]["fusion"]["macro_f1"], 0.9)
        self.assertEqual(result["best_scored_candidate"], "fusion")
        self.assertFalse(result["safety"]["candidates"]["fusion"]["passed"])
        self.assertEqual(result["decision"], "promote")
        self.assertEqual(result["selected_candidate"], "guarded")

    def test_required_classes_and_matched_support(self):
        for label in ("Acetaldehyde", "Ethanol"):
            with self.subTest(missing=label):
                before, after = deepcopy(self.incumbent), deepcopy(self.improved)
                before["per_class"][label]["support"] = after["per_class"][label]["support"] = 0
                result = decision.assess(before, {"fusion": after}, evidence="independent_released")
                self.assertEqual(result["decision"], "keep")
                self.assertIn({"criterion": "missing_required_class", "class": label},
                              result["agent_summary"]["failed_checks"])
        self.improved["per_class"]["Ammonia"]["support"] = 19
        result = decision.assess(self.incumbent, {"fusion": self.improved}, evidence="independent_released")
        self.assertEqual(result["decision"], "keep")
        self.assertIn({"criterion": "missing_or_mismatched_support", "class": "Ammonia"},
                      result["agent_summary"]["failed_checks"])

    def test_policy_is_configurable_without_changing_score(self):
        result = decision.assess(self.incumbent, {"fusion": self.improved}, evidence="independent_released",
                                 thresholds={"min_acetaldehyde_precision": 0.8})
        self.assertEqual(result["decision"], "keep")
        self.assertEqual(result["reason"], "guardrails_failed")
        self.assertEqual(result["competition"]["candidates"]["fusion"]["macro_f1"], 0.8)
        self.assertIn({"criterion": "min_acetaldehyde_precision", "class": "Acetaldehyde"},
                      result["agent_summary"]["failed_checks"])
        self.assertEqual(result["agent_summary"], json.loads(json.dumps(result["agent_summary"], allow_nan=False)))


if __name__ == "__main__":
    unittest.main()
