"""Source-only coverage for the acetaldehyde runner and its model boundary."""

import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
import advance as a


ROOT = HERE.parent
TRAIN = a.ex.SOURCE
PARENT = a.ex.INCUMBENT
FUSION = HERE / "round_01" / "candidate.npz"
RECEIPT = FUSION.with_name("selection.json")
RUN = HERE / "round_04_verified"


class BoundaryTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fusion = a.load_fusion(FUSION, PARENT)
        receipt = a.read_receipt(RECEIPT, FUSION, PARENT)
        cls.source = a.read_source(TRAIN, receipt, cls.fusion.meta["paths"])

    def test_projection_cancels_matched_log_rate_tilts(self):
        x = self.source["x"]
        initial = a.ex.transform(x, "kinetics")
        for case, by_type in (("tilt_mixed", False), ("tilt_negative", False), ("type_tilt", True)):
            modified = a.ex.transform(a.stress(x, case, 1009), "kinetics")
            self.assertTrue(a.np.allclose(a.project(initial, by_type), a.project(modified, by_type), atol=1e-12))

    def test_fusion_unchanged_and_veto_edits_only_new_acetaldehyde(self):
        x = a.stress(self.source["x"], "gain_time", 2027)
        states = a.load_states(RUN / "study_state.npz", RUN / "study.json", FUSION, PARENT, self.source["sha256"])
        models = a.Models(self.fusion, states)
        base = models.predict(x, "stable")
        fusion = models.predict(x, "fusion")
        a.np.testing.assert_array_equal(fusion, self.fusion.predict(x))
        for variant in ("witness_veto", "score_veto"):
            result = models.predict(x, variant)
            changed = a.np.any(result != fusion, axis=1)
            self.assertTrue(changed.any())
            self.assertTrue((fusion.argmax(axis=1)[changed] == a.FOCUS).all())
            self.assertTrue((base.argmax(axis=1)[changed] != a.FOCUS).all())
            a.np.testing.assert_array_equal(result[changed], base[changed])

    def test_checkpoint_identity(self):
        with TemporaryDirectory(prefix=".test-", dir=HERE) as tmp:
            bad = Path(tmp) / "changed.npz"
            bad.write_bytes((RUN / "study_state.npz").read_bytes() + b"extra")
            with self.assertRaisesRegex(ValueError, "study report"):
                a.load_states(bad, RUN / "study.json", FUSION, PARENT, self.source["sha256"])
            with self.assertRaisesRegex(ValueError, "parent"):
                a.load_fusion(FUSION, a.ex.ORIGINAL)
            with self.assertRaisesRegex(ValueError, "exact Batch 1"):
                a.read_source(bad, a.read_receipt(RECEIPT, FUSION, PARENT), self.fusion.meta["paths"])

    def test_portable_review_and_training_overlap(self):
        with TemporaryDirectory(prefix=".test-", dir=HERE) as tmp:
            cwd = Path(tmp)
            cmd = [sys.executable, "-B", str(HERE / "advance.py"), "review", "--incumbent", str(PARENT)]
            no_update = subprocess.run(cmd, cwd=cwd, capture_output=True, check=True, text=True)
            self.assertEqual(json.loads(no_update.stdout)["active_model"], "stable")
            row = json.loads(TRAIN.read_text(encoding="utf-8").splitlines()[0])
            row["id"] = "relabeled-training-row"
            eval_path = cwd / "evaluation.jsonl"
            eval_path.write_text(json.dumps(row) + "\n", encoding="utf-8")
            run = subprocess.run(cmd + ["--variant", "fusion", "--fusion", str(FUSION), "--receipt", str(RECEIPT),
                                        "--train", str(TRAIN), "--evaluation", str(eval_path)],
                                 cwd=cwd, capture_output=True, text=True)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn("training and evaluation rows overlap", run.stderr)


if __name__ == "__main__":
    unittest.main()
