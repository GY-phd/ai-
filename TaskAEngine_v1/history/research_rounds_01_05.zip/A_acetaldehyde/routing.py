"""Source-only test of nuisance-invariant support detection and model fallback."""

import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from time import perf_counter, process_time

import advance as a
from advance import ex, np, rescue

SEEDS = (4001, 5003, 6007)
VARIANTS = ("stable", "fusion", "witness_veto", "raw_support", "projected_support")
VERSION = "a.support-routing.v1"


def representation(x, projected):
    values = ex.transform(x, "kinetics")
    return a.project(values, True) if projected else values


def fit_detector(x, projected):
    values = representation(x, projected)
    center = np.median(values, axis=0)
    low, high = np.percentile(values, (25, 75), axis=0)
    spread = high - low
    scale = np.maximum(spread, max(.05, .1 * float(np.median(spread))))
    z = (values - center) / scale
    _, singular, axes = np.linalg.svd(z, full_matrices=False)
    dimension = min(int(np.searchsorted(np.cumsum(singular ** 2) / sum(singular ** 2), .95)) + 1, z.shape[1] - 1)
    basis = axes[:dimension].T
    residual = np.mean((z - (z @ basis) @ basis.T) ** 2, axis=1)
    # A fixed conservative envelope, with no probability or coverage interpretation.
    cutoff = max(float(np.quantile(residual, .99)) * 4, 1e-8)
    return center, scale, basis, np.array(cutoff)


def unsupported(x, state, projected):
    center, scale, basis, cutoff = state
    z = (representation(x, projected) - center) / scale
    residual = np.mean((z - (z @ basis) @ basis.T) ** 2, axis=1)
    return residual > cutoff


def predict_all(models, detectors, x):
    base = models.predict(x, "stable")
    fused = models.from_base(x, base, "fusion")
    witness = models.from_base(x, base, "witness_veto", fused)
    predictions = {"stable": base, "fusion": fused, "witness_veto": witness}
    flags = {}
    for key, projected in (("raw_support", False), ("projected_support", True)):
        flags[key] = unsupported(x, detectors[key], projected)
        values = witness.copy()
        values[flags[key]] = base[flags[key]]
        predictions[key] = values
    return predictions, flags


def study(args):
    if args.output.exists():
        raise FileExistsError(args.output)
    receipt = a.read_receipt(args.receipt, args.fusion, args.incumbent)
    fusion = a.load_fusion(args.fusion, args.incumbent)
    train = a.read_source(args.train, receipt, fusion.meta["paths"])
    x, y = train["x"], train["y"]
    assignment, groups = ex.source_folds(x, y)
    splits = {"group_0": assignment == 0, "group_1": assignment == 1, "month_1_reverse": np.arange(len(x)) < 248}
    started, cpu_started = perf_counter(), process_time()
    records = []
    for split, test in splits.items():
        states = {"witness_veto": rescue.fit_binary(x[~test], y[~test], "rising_over_steady", 1.)}
        detectors = {"raw_support": fit_detector(x[~test], False), "projected_support": fit_detector(x[~test], True)}
        for seed in SEEDS:
            control = ex.source_control(train, ~test, seed)
            fitted = ex.Candidate.fit(control, x[~test], y[~test], "kinetics", "linear", .5)
            models = a.Models(fitted, states)
            for case in (("clean",) if split == "month_1_reverse" else a.REGULAR + a.CHALLENGE):
                shifted = a.stress(x[test], case, seed)
                predictions, flags = predict_all(models, detectors, shifted)
                records.append({"split": split, "seed": seed, "scenario": case,
                                "models": {name: a.compact(a.score(y[test], values)) for name, values in predictions.items()},
                                "fallback": {name: {"rows": int(flag.sum()), "ethanol": int(sum(flag & (y[test] == a.ETHANOL))),
                                                     "acetaldehyde": int(sum(flag & (y[test] == a.FOCUS)))} for name, flag in flags.items()}})
    summary = {}
    for name in VARIANTS:
        summary[name] = {}
        for scope, subset in (("all", [r for r in records if r["split"] != "month_1_reverse"]),
                              ("regular", [r for r in records if r["split"] != "month_1_reverse" and r["scenario"] in a.REGULAR]),
                              ("challenge", [r for r in records if r["split"] != "month_1_reverse" and r["scenario"] in a.CHALLENGE])):
            values = [r["models"][name] for r in subset]
            stats = {key: [row[key] for row in values if row[key] is not None]
                     for key in ("macro_f1", "ac_precision", "ac_recall", "ethanol_recall")}
            summary[name][scope] = {"mean": {key: float(np.mean(v)) if v else None for key, v in stats.items()},
                                    "worst": {key: min(v) if v else None for key, v in stats.items()},
                                    "ethanol_to_ac": sum(v["ethanol_to_ac"] for v in values),
                                    "precision_undefined_stages": sum(v["ac_precision"] is None for v in values)}
        month = [r["models"][name] for r in records if r["split"] == "month_1_reverse"]
        summary[name]["reverse_month"] = {key: [min(v[key] for v in month), max(v[key] for v in month)]
                                           for key in ("accuracy", "ethanol_recall", "ethanol_to_ac", "false_ac")}
    reviews = {}
    for name in VARIANTS[3:]:
        value, reference, stable = summary[name], summary["witness_veto"], summary["stable"]
        checks = {
            "retains_ac_recall_within_5pp": value["all"]["mean"]["ac_recall"] >= reference["all"]["mean"]["ac_recall"] - .05,
            "retains_mean_macro_f1": value["all"]["mean"]["macro_f1"] >= reference["all"]["mean"]["macro_f1"],
            "challenge_floor_at_least_stable": value["challenge"]["worst"]["macro_f1"] >= stable["challenge"]["worst"]["macro_f1"],
            "reverse_month_false_ac_at_most_witness": value["reverse_month"]["false_ac"][1] <= reference["reverse_month"]["false_ac"][1],
        }
        reviews[name] = {"passed": all(checks.values()), "failed_checks": [key for key, passed in checks.items() if not passed]}
    states = {"witness_veto": rescue.fit_binary(x, y, "rising_over_steady", 1.)}
    detectors = {"raw_support": fit_detector(x, False), "projected_support": fit_detector(x, True)}
    models = a.Models(fusion, states)
    timing = {}
    for name in VARIANTS:
        start = process_time()
        for _ in range(100):
            if name in VARIANTS[:3]:
                models.predict(x, name)
            else:
                base = models.predict(x, "stable")
                witness = models.from_base(x, base, "witness_veto")
                flag = unsupported(x, detectors[name], name == "projected_support")
                witness[flag] = base[flag]
        timing[name] = {"cpu_ms_per_445_rows": (process_time() - start) * 10, "llm_calls": 0, "llm_tokens": 0}
    report = {"version": VERSION, "scope": "Batch1_only", "seeds": SEEDS, "groups": groups,
              "parameters": {"pca_variance": .95, "training_residual_quantile": .99, "envelope_factor": 4},
              "summary": summary, "stages": records, "source_checks": reviews, "cpu": timing,
              "total_cpu_seconds": process_time() - cpu_started, "total_wall_seconds": perf_counter() - started,
              "receipts": {key: receipt[key] for key in ("train_sha256", "candidate_sha256", "parent_checkpoint_sha256")},
              "code_sha256": {**a.implementation_digests(), "routing.py": ex.checkpoint_digest(Path(__file__))},
              "agent_summary": {"decision": "keep", "active_model": "stable", "evidence": "source_holdout",
                                "source_checks": reviews, "independent_generalization_verified": False, "llm_calls": 0}}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".route-", dir=args.output.parent) as temporary:
        staging = Path(temporary) / "result"
        staging.mkdir()
        state = {"version": VERSION, **{f"{mode}_{key}": value for mode, values in detectors.items()
                                         for key, value in zip(("center", "scale", "basis", "cutoff"), values)},
                 **{f"witness_{key}": value for key, value in zip(("center", "scale", "coef"), states["witness_veto"])}}
        np.savez_compressed(staging / "routing_state.npz", **state)
        report["state_sha256"] = ex.checkpoint_digest(staging / "routing_state.npz")
        ex.save_json(staging / "study.json", report)
        if args.output.exists():
            raise FileExistsError(args.output)
        staging.rename(args.output)
    print(json.dumps(report["agent_summary"]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("train", "incumbent", "fusion", "receipt", "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    study(parser.parse_args())


if __name__ == "__main__":
    main()
