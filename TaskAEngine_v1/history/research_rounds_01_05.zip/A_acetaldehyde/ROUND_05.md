# 第五轮交付与乙醛误报研究

本轮交付 `A_task_delivery_v1.zip`，包含稳定 MLP、第一轮瞬态融合、上升瞬态复核，以及两种按样本检测异常并回退到 MLP 的候选。解压后的包可以独立运行，默认使用稳定 MLP。导出器从已验证源文件提取特征函数，并原样复制基线模型实现，预测结果与研究代码一致。包约 159 KiB。

## 新检测方法

上轮表明复核模型在不同通道、不同速率分别变化时会失效。本轮仅增加一个固定方案，使用 Batch 1 的瞬态特征拟合主成分重构，取累计解释 95% 变化的方向。超过训练重构误差第 99 百分位四倍的样本回到 MLP，其余样本采用已有复核。这些数值在实验前固定，阈值仅是工程包络，不能解释为置信概率。

同时做一个机制对照，先去除各类传感器共同的速率斜率，再计算重构误差。相同增益引起的变化与通道独立变化因此可以表现不同。检测器没有使用标签拟合，完整分类系统的拟合和参数选择仅使用 Batch 1。

本轮两个完整测量段留出、三组新随机种子 4001、5003、6007，以及十种情景，共 60 次配对比较。每折重新拟合 MLP、融合、复核和检测器。另做第 2 月训练、第 1 月测试的三类对照。全流程没有读取或重评 Batch 2。

## 结果

| 本轮 Batch 1 内部情景 | 平均 Macro-F1 | 乙醛精确率 | 乙醛召回 | 乙醇召回 | 挑战集最差 Macro-F1 | CPU 毫秒/445 条 |
|---|---:|---:|---:|---:|---:|---:|
| 稳定 MLP | 0.822 | 89.3% | 42.3% | 80.8% | 0.780 | 2.34 |
| 原瞬态融合 | 0.774 | 66.6% | 65.5% | 79.6% | 0.018 | 5.63 |
| 上升瞬态复核 | 0.797 | 84.2% | 62.6% | 80.8% | 0.049 | 5.00 |
| 原特征检测并回退 | 0.861 | 88.4% | 65.2% | 89.5% | 0.470 | 8.91 |
| 去除共同斜率后检测并回退 | 0.860 | 88.3% | 65.2% | 89.5% | 0.410 | 9.69 |

精确率在该情景有乙醛预测时计算。无乙醛预测的情景数量在 `round_05/study.json` 中单列。表中为本轮同一组随机种子的配对结果，上轮随机种子和扰动不同。CPU 时间为本机重复 100 次的平均模型计算时间，正式容器延迟待测。五种方案的大模型调用与 Token 消耗均为 0。

在各通道、各速率独立变化的情景中，两种检测器均把受影响样本交给 MLP，平均 Macro-F1 达到 0.915，原复核为 0.313。在联合增益和速率变化的情景中，复核和两种检测器的平均 Macro-F1 均为 0.824，稳定 MLP 为 0.545，说明回退并未把这一情景的复核增益消掉。

仍有其他挑战情景漏检，最差 Macro-F1 低于稳定 MLP。去除斜率的检测还没有表现出相对简单检测的一致优势。跨月反向对照中，去除斜率检测与原复核的每次乙醛误报均为 1–10 条，原特征检测为 1–11 条。第 1 月没有乙醛正样本，无法据此计算乙醛跨月召回。

当前 Agent 输出 `keep`。候选改进了内部平均表现，也减少了部分误报，但尚未通过此前确定的最差情景护栏。护栏是本地政策，可由用户或主 Harness 配置，比赛得分按平台规则评定。当前研究没有合法独立批次来确认这种改进是否能泛化，两个乙醛留出段都来自同一月。重复扰动不增加独立采样数量。

## 使用交付包

解压 `A_task_delivery_v1.zip`，进入其中的 `A_task_delivery_v1` 目录。在已有 NumPy 的 Python 环境运行。包可在其他目录使用，预测时只需模型和代码。

```powershell
python -B predict.py --verify
Get-Content -Encoding UTF8 .\requests.jsonl | python -B predict.py
Get-Content -Encoding UTF8 .\requests.jsonl | python -B predict.py --variant projected_support
python -B review.py --output decision.json
```

每行请求包含 `inputs.features`，其值是长度 128 的数值数组。可附 `task` 为 `classification`。输出为六类的 `label` 和 `score`，分数主要用于排序。`--variant` 可取 `stable`、`fusion`、`witness_veto`、`raw_support`、`projected_support`。

`review.py` 默认生成无更新结果。评审某个候选需给出 `--variant`、`--train`、`--evaluation`。它核对训练数据摘要、训练与评估行是否重叠，以及模型文件摘要。公开开发数据只产生保留决定。合法独立评估还需调用方显式给出 `--evidence independent_released --release-id <释放记录编号>`。数据是否合法独立由调用方负责核实，程序会拒绝把已知 Batch 2 声明为独立证据。程序输出 `recommended_variant`，实际配置由清单中的 `active_variant` 指定。

`competition` 给出 Macro-F1 和准确率，`safety` 给出本地护栏，`agent_summary` 提供给主 Harness 的简短决策。只评审一个预先指定的候选，训练标签始终与评估标签隔离。评审结果可以保留、批准或拒绝候选，原始模型文件均通过摘要追溯。

## 复现实验与构建

在比赛根目录执行，输出目录需为新目录。

```powershell
$py = '.\.venv\Scripts\python.exe'
$train = '.\任务A\public\train.jsonl'
$parent = '.\my-second-run\checkpoint.npz'
$fusion = '.\A_acetaldehyde\round_01\candidate.npz'
$receipt = '.\A_acetaldehyde\round_01\selection.json'
& $py -B .\A_acetaldehyde\routing.py --train $train --incumbent $parent --fusion $fusion --receipt $receipt --output .\A_acetaldehyde\round_05_repro
& $py -B .\A_acetaldehyde\export_bundle.py --incumbent $parent --fusion $fusion --receipt $receipt --study .\A_acetaldehyde\round_05\study.json --state .\A_acetaldehyde\round_05\routing_state.npz --output .\A_acetaldehyde\delivery_repro
& $py -B -m unittest discover -s .\A_acetaldehyde\tests -v
```

完成 11 项专项测试和原始 9 项基线测试。新增测试核对了迁移目录、五种模型输出与原实现一致、逐条和批量预测一致、默认无更新，以及损坏检查点被拒绝。使用人工构造样本验证了配对评审入口。相同实验重新执行后逐情景指标与状态文件完全一致，同名重新导出的 ZIP 逐字节一致。第四轮及以前的源代码和模型摘要均通过检查。

可用的运行包、模型、研究记录和本地评审接口已经交付。正式 SDK、Linux 容器运行、SwanLab 平台记录和合法独立跨月数据仍未在当前项目中获得验证。本轮没有将本地日志标为平台训练记录。下一步的正式验证可以直接固定这五个候选，先由团队确认数据释放和评分调用协议，再运行配对评估。
