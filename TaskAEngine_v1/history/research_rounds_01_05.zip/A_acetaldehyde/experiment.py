"""Select a gas-sensor candidate on Batch 1, then score the frozen candidate."""

import argparse
import json
import platform
import sys
from pathlib import Path
from time import perf_counter, process_time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "任务A"))
from baselines.model import Model, checkpoint_digest
from baselines.data import json_value, read_dataset
from baselines.predict import predict as format_prediction
import numpy as np

from rollout import review


SOURCE = ROOT / "任务A" / "public" / "train.jsonl"
PUBLIC = SOURCE.with_name("validation.jsonl")
ORIGINAL = SOURCE.parents[1] / "checkpoint.npz"
INCUMBENT = ROOT / "my-second-run" / "checkpoint.npz"
CONFIG = json.loads((ORIGINAL.parent / "baselines" / "configs" / "A.json").read_text())
CLASSES = CONFIG["classes"]
FOCUS = CLASSES.index("Acetaldehyde")
VIEWS = ("raw", "log", "steady_profile", "kinetics", "rising_over_steady", "profile_kinetics", "all_profiles")
METHODS = ("linear", "rbf", "lda")
WEIGHTS = (0.5, 0.8, 1.0)
VERSION = "a.sensor-candidate.v1"


def transform(x, view):
    s = x.reshape(-1, 16, 8)
    if view == "raw":
        return x
    if view == "log":
        return np.sign(x) * np.log1p(np.abs(x))

    # Absolute steady response and positive peak/baseline ratio are features 1 and 2.
    steady = np.sign(s[:, :, 0]) * np.log1p(np.abs(s[:, :, 0]))
    relative_delta = s[:, :, 1] - 1
    relative = np.sign(relative_delta) * np.log1p(np.abs(relative_delta))
    steady -= steady.mean(axis=1, keepdims=True)
    relative -= relative.mean(axis=1, keepdims=True)
    ema = np.log(np.maximum(np.abs(s[:, :, 2:]), 1e-3))
    log_amplitude = np.log(np.maximum(np.abs(s[:, :, :1]), 1e-3))
    rising_over_steady = (ema[:, :, :3] - log_amplitude).reshape(len(x), 48)
    kinetic = np.concatenate((ema[:, :, 1:3] - ema[:, :, :1],
                              ema[:, :, 4:6] - ema[:, :, 3:4],
                              ema[:, :, 3:4] - ema[:, :, :1]), axis=2).reshape(len(x), 80)
    if view == "steady_profile":
        return np.column_stack((steady, relative))
    if view == "kinetics":
        return kinetic
    if view == "rising_over_steady":
        return rising_over_steady
    if view == "profile_kinetics":
        return np.column_stack((steady, relative, rising_over_steady))
    ema -= ema.mean(axis=1, keepdims=True)
    return np.column_stack((steady, relative, ema.reshape(len(x), 96)))


def softmax(scores):
    exp = np.exp(scores - scores.max(axis=1, keepdims=True))
    return exp / exp.sum(axis=1, keepdims=True)


class Candidate:
    def __init__(self, parent, view, method, weight, mean, scale, basis, coef, bandwidth):
        self.parent = parent
        self.meta = parent.meta
        if view not in VIEWS or method not in METHODS or weight not in WEIGHTS or not bandwidth > 0:
            raise ValueError("invalid sensor candidate configuration")
        self.view, self.method, self.weight = view, method, weight
        self.mean, self.scale = mean, scale
        self.basis, self.coef, self.bandwidth = basis, coef, bandwidth

    @staticmethod
    def squared_distances(x, y):
        return np.maximum((x * x).sum(axis=1)[:, None] + (y * y).sum(axis=1) - 2 * x @ y.T, 0)

    @classmethod
    def fit(cls, parent, x, y, view, method, weight):
        features = transform(x, view)
        mean = np.median(features, axis=0)
        # Training-only robust scaling with a floor for nearly constant features.
        lower, upper = np.percentile(features, (25, 75), axis=0)
        iqr = upper - lower
        scale = np.maximum(iqr, max(1e-6, 0.1 * float(np.median(iqr))))
        z = np.clip((features - mean) / scale, -6, 6)
        if method == "lda":
            centers = np.stack([z[y == i].mean(axis=0) for i in range(len(CLASSES))])
            residuals = z - centers[y]
            covariance = residuals.T @ residuals / (len(y) - len(CLASSES))
            shrinkage = 0.15
            covariance = (1 - shrinkage) * covariance + shrinkage * np.eye(z.shape[1]) * np.trace(covariance) / z.shape[1]
            coef = np.linalg.solve(covariance + 1e-6 * np.eye(z.shape[1]), centers.T)
            intercept = -0.5 * np.sum(centers.T * coef, axis=0)
            return cls(parent, view, method, weight, mean, scale, np.empty((0, z.shape[1])),
                       np.vstack((intercept, coef)), 1.)
        target = np.eye(len(CLASSES))[y]
        row_weight = np.sqrt(len(y) / (len(CLASSES) * np.bincount(y, minlength=len(CLASSES))[y]))
        if method == "linear":
            design = np.column_stack((np.ones(len(z)), z))
            weighted = design * row_weight[:, None]
            coef = np.linalg.solve(weighted.T @ weighted + np.eye(weighted.shape[1]),
                                   weighted.T @ (target * row_weight[:, None]))
            return cls(parent, view, method, weight, mean, scale, np.empty((0, z.shape[1])), coef, 1.)
        distance = cls.squared_distances(z, z)
        bandwidth = max(float(np.median(distance[np.triu_indices(len(z), k=1)])), 1e-8)
        kernel = np.exp(-distance / bandwidth)
        coef = np.linalg.solve(kernel + np.diag(0.03 / row_weight ** 2), target)
        return cls(parent, view, method, weight, mean, scale, z, coef, bandwidth)

    def auxiliary(self, x):
        z = np.clip((transform(x, self.view) - self.mean) / self.scale, -6, 6)
        if self.method != "rbf":
            design = np.column_stack((np.ones(len(z)), z))
        else:
            design = np.exp(-self.squared_distances(z, self.basis) / self.bandwidth)
        return softmax((0.25 if self.method == "lda" else 6) * (design @ self.coef))

    def predict(self, x):
        auxiliary = self.auxiliary(x)
        if self.weight == 1:
            return auxiliary
        return (1 - self.weight) * self.parent.predict(x) + self.weight * auxiliary

    def save(self, path, parent_digest):
        with path.open("xb") as output:
            np.savez_compressed(output, version=VERSION, parent_digest=parent_digest, view=self.view,
                                method=self.method, weight=self.weight, mean=self.mean, scale=self.scale,
                                basis=self.basis, coef=self.coef, bandwidth=self.bandwidth)

    @classmethod
    def load(cls, path, parent_path):
        parent = Model.load(parent_path)
        with np.load(path, allow_pickle=False) as state:
            if str(state["version"]) != VERSION or str(state["parent_digest"]) != checkpoint_digest(parent_path):
                raise ValueError("candidate format or parent checkpoint digest mismatch")
            return cls(parent, str(state["view"]), str(state["method"]), float(state["weight"]),
                       state["mean"], state["scale"], state["basis"], state["coef"], float(state["bandwidth"]))


def score(expected, probabilities):
    labels = probabilities.argmax(axis=1)
    matrix = np.zeros((len(CLASSES), len(CLASSES)), dtype=int)
    np.add.at(matrix, (expected, labels), 1)
    correct, support, predicted = matrix.diagonal(), matrix.sum(axis=1), matrix.sum(axis=0)
    per_class = {}
    for i, name in enumerate(CLASSES):
        per_class[name] = {
            "support": int(support[i]), "correct": int(correct[i]), "predicted": int(predicted[i]),
            "precision": float(correct[i] / max(1, predicted[i])),
            "recall": float(correct[i] / max(1, support[i])),
            "f1": float(2 * correct[i] / max(1, support[i] + predicted[i])),
        }
    return {"macro_f1": float(np.mean([v["f1"] for v in per_class.values()])),
            "accuracy": float(correct.sum() / support.sum()), "per_class": per_class,
            "worst_recall": min(v["recall"] for v in per_class.values() if v["support"]),
            "confusion_matrix": matrix.tolist()}


def source_folds(x, y):
    amplitude = np.median(np.log1p(np.abs(x[:, ::8])), axis=1)
    assignment = np.empty(len(x), dtype=int)
    by_class = {}
    for i, name in enumerate(CLASSES):
        rows = np.flatnonzero(y == i)
        splits = np.flatnonzero((np.diff(rows) > 1) | (np.diff(amplitude[rows]) < -0.5)) + 1
        groups = np.split(rows, splits)
        counts = [0, 0]
        by_class[name] = []
        for group in sorted(groups, key=len, reverse=True):
            fold = int(np.argmin(counts))
            counts[fold] += len(group)
            assignment[group] = fold
            by_class[name].append({"first_row": int(group[0] + 1), "last_row": int(group[-1] + 1), "fold": fold})
        if min(counts) == 0:
            raise ValueError(f"need two source measurement runs for {name}")
    return assignment, by_class


def stressed(x, case, seed):
    if case == "clean":
        return x
    rng = np.random.default_rng(seed)
    sample = rng.uniform(-0.15, 0.15, (len(x), 1))
    group = np.tile(np.repeat(np.arange(4), 2), 2)
    channel_gain = rng.normal(0, .18, (1, 16))
    type_gain = rng.normal(0, .4 if case == "gain_time" else .18, (1, 4))[:, group]
    gain = channel_gain + type_gain
    reference = rng.normal(0, .2 if case == "gain_time" else .1, (1, 4))[:, group]
    s = x.reshape(-1, 16, 8).copy()
    response = sample + {"weak": -0.8, "strong": 0.8, "gain_time": 0.0}[case]
    s[:, :, 0] *= np.exp(response + gain)
    s[:, :, 1] = np.maximum(1e-6, 1 + (s[:, :, 1] - 1) * np.exp(response + gain - reference))
    rate = np.tile([-1., 0., 1.], 2) * (0.3 if case == "gain_time" else 0.1)
    s[:, :, 2:] *= np.exp((response + gain)[:, :, None] + rate)
    return s.reshape(-1, 128)


def source_control(train, fit, seed):
    model = Model("classification", train["paths"], CLASSES, train["x"][fit], train["y"][fit],
                  hidden=32, seed=seed, learning_rate=.003, batch_size=128)
    model.fit(train["x"][fit], train["y"][fit], 20)
    model.meta["learning_rate"] = .001
    model.fit(train["x"][fit], train["y"][fit], 20)
    return model


def select(train_path, parent_path, output):
    parent = Model.load(parent_path)
    train = read_dataset(train_path, "classification", CLASSES, parent.meta["paths"])
    if parent.meta["classes"] != CLASSES or len(train["paths"]) != 128:
        raise ValueError("expected the A checkpoint and 128 sensor features")
    assignment, groups = source_folds(train["x"], train["y"])
    seeds = (42, 73)
    cases = ("clean", "weak", "strong", "gain_time")
    results = {("control", "mlp", 0.): []}
    results.update({(view, method, weight): [] for view in VIEWS for method in METHODS for weight in WEIGHTS})
    start, cpu_start = perf_counter(), process_time()
    for fold in (0, 1):
        fit = assignment != fold
        valid = ~fit
        x_fit, y_fit = train["x"][fit], train["y"][fit]
        candidates = {(view, method): Candidate.fit(parent, x_fit, y_fit, view, method, 1.)
                      for view in VIEWS for method in METHODS}
        for seed in seeds:
            control = source_control(train, fit, seed)
            for case in cases:
                x = stressed(train["x"][valid], case, seed + fold)
                y = train["y"][valid]
                base = control.predict(x)
                results[("control", "mlp", 0.)].append((fold, seed, case, score(y, base)))
                for (view, method), model in candidates.items():
                    auxiliary = model.auxiliary(x)
                    for weight in WEIGHTS:
                        blended = (1 - weight) * base + weight * auxiliary
                        results[(view, method, weight)].append((fold, seed, case, score(y, blended)))

    def summarize(config, runs):
        macro = [m["macro_f1"] for _, _, _, m in runs]
        focus = [m["per_class"][CLASSES[FOCUS]]["f1"] for _, _, _, m in runs]
        # Equal weight to six-class performance and the weakest acetaldehyde condition.
        utility = 0.5 * float(np.mean(macro)) + 0.5 * float(min(focus))
        return {"view": config[0], "method": config[1], "auxiliary_weight": config[2], "utility": utility,
                "mean_macro_f1": float(np.mean(macro)), "worst_macro_f1": float(min(macro)),
                "mean_acetaldehyde_f1": float(np.mean(focus)), "worst_acetaldehyde_f1": float(min(focus)),
                "runs": [{"fold": fold, "seed": seed, "case": case, "metrics": m}
                         for fold, seed, case, m in runs]}

    rankings = sorted((summarize(key, runs) for key, runs in results.items()),
                      key=lambda row: (row["utility"], row["worst_macro_f1"]), reverse=True)
    best = next(row for row in rankings if row["method"] != "mlp")
    fit_start, fit_cpu = perf_counter(), process_time()
    model = Candidate.fit(parent, train["x"], train["y"], best["view"], best["method"], best["auxiliary_weight"])
    fit_seconds, fit_cpu_seconds = perf_counter() - fit_start, process_time() - fit_cpu
    parent_digest = checkpoint_digest(parent_path)
    output.mkdir(parents=True, exist_ok=False)
    checkpoint = output / "candidate.npz"
    model.save(checkpoint, parent_digest)
    summary = {"format": VERSION, "experiment_id": output.name, "train_rows": len(train["y"]),
               "train_sha256": train["sha256"], "parent_checkpoint_sha256": parent_digest,
               "candidate_sha256": checkpoint_digest(checkpoint), "classes": CLASSES,
               "code_sha256": checkpoint_digest(Path(__file__)), "rollout_sha256": checkpoint_digest(Path(__file__).with_name("rollout.py")),
               "seeds": seeds, "cases": cases,
               "group_ranges": groups, "ranking": rankings, "python": platform.python_version(),
               "numpy": np.__version__, "selection_seconds": perf_counter() - start,
               "selection_cpu_seconds": process_time() - cpu_start, "fit_seconds": fit_seconds,
               "fit_cpu_seconds": fit_cpu_seconds, "llm_calls": 0,
               "selected": {key: val for key, val in best.items() if key != "runs"}}
    save_json(output / "selection.json", summary)
    print(json.dumps(summary["selected"]))


def save_json(path, data):
    with path.open("x", encoding="utf-8") as output:
        json.dump(data, output, indent=2, ensure_ascii=False, allow_nan=False)
        output.write("\n")


def evaluate(train_path, evaluation_path, parent_path, output):
    result_file = output / "public_evaluation.json"
    if result_file.exists():
        raise FileExistsError(result_file)
    checkpoint = output / "candidate.npz"
    selection = json.loads((output / "selection.json").read_text(encoding="utf-8"))
    if selection["candidate_sha256"] != checkpoint_digest(checkpoint):
        raise ValueError("checkpoint changed after selection")
    if (selection["code_sha256"] != checkpoint_digest(Path(__file__)) or
            selection["rollout_sha256"] != checkpoint_digest(Path(__file__).with_name("rollout.py"))):
        raise ValueError("experiment or rollout code changed after selection")
    model = Candidate.load(checkpoint, parent_path)
    train = read_dataset(train_path, "classification", CLASSES, model.meta["paths"])
    if selection["train_sha256"] != train["sha256"]:
        raise ValueError("training file changed after selection")
    data = read_dataset(evaluation_path, "classification", CLASSES, model.meta["paths"])
    if set(train["ids"]) & set(data["ids"]) or set(map(tuple, train["x"])) & set(map(tuple, data["x"])):
        raise ValueError("training and evaluation overlap")
    original = Model.load(ORIGINAL)
    metrics = {}
    for name, estimator in (("original", original), ("incumbent", model.parent), ("candidate", model)):
        start = perf_counter()
        probabilities = estimator.predict(data["x"])
        seconds = perf_counter() - start
        metrics[name] = score(data["y"], probabilities)
        metrics[name]["batch_prediction_seconds"] = seconds
    result = {"format": VERSION, "experiment_id": selection["experiment_id"], "evaluation_rows": len(data["y"]),
              "evaluation_sha256": data["sha256"], "classes": CLASSES, "metrics": metrics,
              "candidate_sha256": selection["candidate_sha256"], "selected": selection["selected"],
              "rollout": review(metrics["incumbent"], metrics["candidate"])}
    save_json(result_file, result)
    print(json.dumps({"macro_f1": {name: m["macro_f1"] for name, m in metrics.items()},
                      "acetaldehyde": {name: m["per_class"]["Acetaldehyde"] for name, m in metrics.items()},
                      "rollout": result["rollout"]}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("select", "evaluate", "predict"))
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--train", type=Path, default=SOURCE)
    parser.add_argument("--evaluation", type=Path, default=PUBLIC)
    parser.add_argument("--parent", type=Path, default=INCUMBENT)
    args = parser.parse_args()
    if args.action == "select":
        select(args.train, args.parent, args.run)
    elif args.action == "evaluate":
        evaluate(args.train, args.evaluation, args.parent, args.run)
    else:
        model = Candidate.load(args.run / "candidate.npz", args.parent)
        for line in sys.stdin:
            if line.strip():
                request = json_value(line)
                if not isinstance(request, dict) or set(request) - {"task", "inputs"} or "inputs" not in request:
                    raise ValueError("prediction request requires only task and inputs")
                if request.get("task", "classification") != "classification":
                    raise ValueError("prediction task mismatch")
                print(json.dumps(format_prediction(model, request["inputs"]), allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
