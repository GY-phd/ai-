"""Train and test an ethanol-to-acetaldehyde correction using only source labels."""

import argparse
import json
from pathlib import Path
import sys
from time import perf_counter, process_time

import experiment as ex
from experiment import CLASSES, FOCUS, INCUMBENT, ORIGINAL, PUBLIC, SOURCE
from experiment import Model, checkpoint_digest, format_prediction, json_value, np, read_dataset, score
from rollout import review


ETHANOL = CLASSES.index("Ethanol")
VERSION = "a.acetaldehyde-rescue.v1"
VIEWS = ("kinetics", "rising_over_steady", "rising_shape", "centered_rising", "steady_profile",
         "within_type_steady", "within_type_rising", "rising_and_within_type")
CUTOFFS = (0.0, 0.25, 0.5, 0.75)
CASES = ("clean", "weak", "strong", "gain_time", "sensor_gain")
SEEDS = (42, 73, 131)
GROUP = np.tile(np.repeat(np.arange(4), 2), 2)


def features(x, view):
    if view in ("kinetics", "rising_over_steady", "steady_profile"):
        return ex.transform(x, view)
    sensors = x.reshape(-1, 16, 8)
    log_rise = np.log(np.maximum(np.abs(sensors[:, :, 2:5]), 1e-3))
    log_steady = np.log(np.maximum(np.abs(sensors[:, :, :1]), 1e-3))
    if view == "rising_shape":
        return (log_rise[:, :, 1:] - log_rise[:, :, :1]).reshape(len(x), 32)
    if view == "centered_rising":
        return (log_rise - log_rise.mean(axis=1, keepdims=True)).reshape(len(x), 48)
    if view == "within_type_rising":
        return within_type(log_rise)
    if view == "within_type_steady":
        return within_type(log_steady)
    return np.column_stack((ex.transform(x, "rising_over_steady"), within_type(log_rise), within_type(log_steady)))


def within_type(values):
    averages = np.stack([values[:, GROUP == index].mean(axis=1) for index in range(4)], axis=1)
    return (values - averages[:, GROUP]).reshape(len(values), -1)


def stress(x, case, seed):
    if case != "sensor_gain":
        return ex.stressed(x, case, seed)
    rng = np.random.default_rng(seed)
    values = x.reshape(-1, 16, 8).copy()
    gain = rng.normal(0, .45, (1, 4))[:, GROUP] + rng.normal(0, .13, (1, 16))
    values[:, :, 0] *= np.exp(gain)
    values[:, :, 1] = np.maximum(1e-6, 1 + (values[:, :, 1] - 1) * np.exp(0.5 * gain))
    values[:, :, 2:] *= np.exp(gain[:, :, None])
    return values.reshape(-1, 128)


def fit_binary(x, y, view, regularization):
    use = (y == ETHANOL) | (y == FOCUS)
    x, y = x[use], y[use]
    # Fixed synthetic environments only. Test seeds are disjoint from augmentation seeds.
    replicas = [x] + [stress(x, case, seed) for case in CASES[1:] for seed in (12, 31, 54)]
    z = features(np.concatenate(replicas), view)
    center = np.median(z, axis=0)
    q25, q75 = np.percentile(z, (25, 75), axis=0)
    iqr = q75 - q25
    scale = np.maximum(iqr, max(1e-6, 0.1 * float(np.median(iqr))))
    design = design_matrix(z, center, scale)
    target = np.tile(np.where(y == FOCUS, 1., -1.), len(replicas))
    weights = np.sqrt(np.where(target > 0, len(y) / (2 * sum(y == FOCUS)), len(y) / (2 * sum(y == ETHANOL))))
    weighted = design * weights[:, None]
    penalty = regularization * len(replicas) * np.eye(weighted.shape[1])
    penalty[0, 0] = 0
    coefficients = np.linalg.solve(weighted.T @ weighted + penalty, weighted.T @ (target * weights))
    return center, scale, coefficients


def design_matrix(z, center, scale):
    return np.column_stack((np.ones(len(z)), np.clip((z - center) / scale, -6, 6)))


def margin(x, view, state):
    center, scale, coefficients = state
    return design_matrix(features(x, view), center, scale) @ coefficients


def correct(probabilities, margins, cutoff):
    rescue = (probabilities.argmax(axis=1) == ETHANOL) & (margins > cutoff)
    result = probabilities.copy()
    result[rescue, ETHANOL] = probabilities[rescue, FOCUS]
    result[rescue, FOCUS] = probabilities[rescue, ETHANOL]
    return result


class Rescue:
    def __init__(self, parent, view, cutoff, state):
        self.parent, self.meta = parent, parent.meta
        self.view, self.cutoff, self.state = view, cutoff, state

    def predict(self, x):
        return correct(self.parent.predict(x), margin(x, self.view, self.state), self.cutoff)

    @classmethod
    def load(cls, path, parent_path):
        parent = Model.load(parent_path)
        with np.load(path, allow_pickle=False) as state:
            view, cutoff = str(state["view"]), float(state["cutoff"])
            if (str(state["version"]) != VERSION or str(state["parent_digest"]) != checkpoint_digest(parent_path)
                    or view not in VIEWS or cutoff not in CUTOFFS):
                raise ValueError("invalid rescue state or parent checkpoint digest mismatch")
            return cls(parent, view, cutoff, (state["center"], state["scale"], state["coefficients"]))


def source_selection(train, parent):
    assignment, groups = ex.source_folds(train["x"], train["y"])
    configs = [(view, regularization, cutoff) for view in VIEWS for regularization in (1., 10.) for cutoff in CUTOFFS]
    results = {config: [] for config in configs}
    baseline = []
    for fold in (0, 1):
        fit, test = assignment != fold, assignment == fold
        states = {(view, reg): fit_binary(train["x"][fit], train["y"][fit], view, reg)
                  for view in VIEWS for reg in (1., 10.)}
        for seed in SEEDS:
            control = ex.source_control(train, fit, seed)
            for case in CASES:
                x, y = stress(train["x"][test], case, seed + fold), train["y"][test]
                probabilities = control.predict(x)
                incumbent = score(y, probabilities)
                baseline.append({"fold": fold, "seed": seed, "case": case, "metrics": incumbent})
                margins = {(view, reg): margin(x, view, state) for (view, reg), state in states.items()}
                for view, reg, cutoff in configs:
                    candidate = score(y, correct(probabilities, margins[view, reg], cutoff))
                    results[view, reg, cutoff].append({"fold": fold, "seed": seed, "case": case, "metrics": candidate})

    def summarize(config, runs):
        macros = [r["metrics"]["macro_f1"] for r in runs]
        focus_f1 = [r["metrics"]["per_class"]["Acetaldehyde"]["f1"] for r in runs]
        losses = [base["metrics"]["per_class"]["Ethanol"]["recall"] - r["metrics"]["per_class"]["Ethanol"]["recall"]
                  for base, r in zip(baseline, runs)]
        utility = 0.5 * float(np.mean(macros)) + 0.5 * float(np.mean(focus_f1)) - float(max(losses))
        return {"view": config[0], "regularization": config[1], "cutoff": config[2], "utility": utility,
                "mean_macro_f1": float(np.mean(macros)), "mean_acetaldehyde_f1": float(np.mean(focus_f1)),
                "max_ethanol_recall_drop": float(max(losses)), "runs": runs}

    rankings = sorted((summarize(config, results[config]) for config in configs),
                      key=lambda row: row["utility"], reverse=True)
    best = rankings[0]
    selection = {key: value for key, value in best.items() if key != "runs"}
    started, cpu_started = perf_counter(), process_time()
    state = fit_binary(train["x"], train["y"], best["view"], best["regularization"])
    selection["fit_seconds"] = perf_counter() - started
    selection["fit_cpu_seconds"] = process_time() - cpu_started
    return selection, state, {"ranking": rankings, "baseline": baseline, "groups": groups}


def code_digests():
    return {name: checkpoint_digest(Path(__file__).with_name(name))
            for name in ("rescue.py", "experiment.py", "rollout.py")}


def select(train_path, parent_path, run):
    parent = Model.load(parent_path)
    train = read_dataset(train_path, "classification", CLASSES, parent.meta["paths"])
    if parent.meta["classes"] != CLASSES or len(train["paths"]) != 128:
        raise ValueError("expected the A checkpoint and 128 sensor features")
    started, cpu_started = perf_counter(), process_time()
    selected, state, details = source_selection(train, parent)
    run.mkdir(parents=True, exist_ok=False)
    parent_digest = checkpoint_digest(parent_path)
    checkpoint = run / "rescue.npz"
    with checkpoint.open("xb") as output:
        np.savez_compressed(output, version=VERSION, view=selected["view"], cutoff=selected["cutoff"],
                            parent_digest=parent_digest, center=state[0], scale=state[1], coefficients=state[2])
    ex.save_json(run / "selection.json", {"format": VERSION, "experiment_id": run.name, "selected": selected,
                                         "seeds": SEEDS, "cases": CASES, "classes": CLASSES,
                                         "train_rows": len(train["y"]), "train_sha256": train["sha256"],
                                         "parent_checkpoint_sha256": parent_digest,
                                         "candidate_sha256": checkpoint_digest(checkpoint), "code_sha256": code_digests(),
                                         "selection_seconds": perf_counter() - started,
                                         "selection_cpu_seconds": process_time() - cpu_started, "llm_calls": 0,
                                         **details})
    print(json.dumps(selected))


def evaluate(train_path, evaluation_path, parent_path, run):
    target = run / "public_evaluation.json"
    if target.exists():
        raise FileExistsError(target)
    checkpoint = run / "rescue.npz"
    selected = json.loads((run / "selection.json").read_text(encoding="utf-8"))
    if selected["candidate_sha256"] != checkpoint_digest(checkpoint) or selected["code_sha256"] != code_digests():
        raise ValueError("checkpoint or code changed after selection")
    model = Rescue.load(checkpoint, parent_path)
    train = read_dataset(train_path, "classification", CLASSES, model.meta["paths"])
    if selected["train_sha256"] != train["sha256"]:
        raise ValueError("training data changed after selection")
    data = read_dataset(evaluation_path, "classification", CLASSES, model.meta["paths"])
    if set(train["ids"]) & set(data["ids"]) or set(map(tuple, train["x"])) & set(map(tuple, data["x"])):
        raise ValueError("training and evaluation overlap")
    metrics = {}
    for name, estimator in (("original", Model.load(ORIGINAL)), ("incumbent", model.parent), ("candidate", model)):
        started = perf_counter()
        probabilities = estimator.predict(data["x"])
        seconds = perf_counter() - started
        metrics[name] = score(data["y"], probabilities)
        metrics[name]["batch_prediction_seconds"] = seconds
    result = {"format": VERSION, "experiment_id": run.name, "evaluation_sha256": data["sha256"],
              "evaluation_rows": len(data["y"]), "metrics": metrics, "classes": CLASSES,
              "candidate_sha256": selected["candidate_sha256"], "selected": selected["selected"],
              "rollout": review(metrics["incumbent"], metrics["candidate"])}
    ex.save_json(target, result)
    print(json.dumps({"macro_f1": {name: m["macro_f1"] for name, m in metrics.items()},
                      "acetaldehyde": metrics["candidate"]["per_class"]["Acetaldehyde"], "rollout": result["rollout"]}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("select", "evaluate", "predict"))
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--train", type=Path, default=SOURCE)
    parser.add_argument("--evaluation", type=Path, default=PUBLIC)
    parser.add_argument("--parent", type=Path, default=INCUMBENT)
    args = parser.parse_args()
    if args.action == "select":
        select(args.train, args.parent, args.run)
    elif args.action == "evaluate":
        evaluate(args.train, args.evaluation, args.parent, args.run)
    else:
        model = Rescue.load(args.run / "rescue.npz", args.parent)
        for line in sys.stdin:
            if line.strip():
                request = json_value(line)
                if not isinstance(request, dict) or set(request) - {"task", "inputs"} or "inputs" not in request:
                    raise ValueError("prediction request requires only task and inputs")
                if request.get("task", "classification") != "classification":
                    raise ValueError("prediction task mismatch")
                print(json.dumps(format_prediction(model, request["inputs"]), allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
