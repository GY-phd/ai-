"""Batch 1 stress study, JSONL prediction, and local Task A model-update review."""

import argparse
import json
import platform
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from time import perf_counter, process_time
from types import SimpleNamespace

import experiment as ex
import rescue
from decision import assess
from experiment import CLASSES, FOCUS, Model, checkpoint_digest, np, read_dataset
import rollout


ETHANOL = CLASSES.index("Ethanol")
AC = CLASSES[FOCUS]
ET = CLASSES[ETHANOL]
SEEDS = (1009, 2027, 3091)
REGULAR = ("clean", "weak", "strong", "gain_time", "sensor_gain")
CHALLENGE = ("tilt_positive", "tilt_negative", "tilt_mixed", "type_tilt", "channel_rate")
MODES = ("stable", "fusion", "score_veto", "witness_veto", "phase_projection", "type_projection")
PROJECTED = MODES[-2:]
VERSION = "a.acetaldehyde-boundary.v1"
# Digest from the packaged training report. This set already informed development.
PUBLIC_EVALUATION = "sha256:6be1370388bf67d017f7426a51e149a65baf9bc1186f5f41f6731ce5006ffbee"
SCORE_BINS = ((0., .4), (.4, .5), (.5, .6), (.6, .7), (.7, 1.01))


def project(values, by_type):
    """Remove common log EMA slopes separately for rising and decaying response."""
    z = values.reshape(-1, 16, 5).copy()
    # Compare the two phases at the middle rate, the fixed point of this tilt model.
    z[:, :, 4] += z[:, :, 2] - z[:, :, 0]
    slopes = np.array([1., 2.])
    groups = [np.arange(16)] if not by_type else [np.flatnonzero(rescue.GROUP == i) for i in range(4)]
    for group in groups:
        part = z[:, group, :4].reshape(len(z), len(group), 2, 2)
        slope = (part @ slopes).mean(axis=1, keepdims=True) / 5
        part -= slope[..., None] * slopes
        z[:, group, :4] = part.reshape(len(z), len(group), 4)
    return z.reshape(len(z), 80)


def fit_projection(x, y, mode):
    z = project(ex.transform(x, "kinetics"), mode == "type_projection")
    center = np.median(z, axis=0)
    low, high = np.percentile(z, (25, 75), axis=0)
    iqr = high - low
    scale = np.maximum(iqr, max(1e-6, 0.1 * float(np.median(iqr))))
    design = rescue.design_matrix(z, center, scale)
    weight = np.sqrt(len(y) / (len(CLASSES) * np.bincount(y)[y]))
    weighted = design * weight[:, None]
    coef = np.linalg.solve(weighted.T @ weighted + np.eye(design.shape[1]),
                           weighted.T @ (np.eye(len(CLASSES))[y] * weight[:, None]))
    return center, scale, coef


def fit_states(x, y):
    return {"witness_veto": rescue.fit_binary(x, y, "rising_over_steady", 1.),
            **{mode: fit_projection(x, y, mode) for mode in PROJECTED}}


class Models:
    def __init__(self, fusion, states):
        self.fusion, self.parent, self.states = fusion, fusion.parent, states
        self.meta = self.parent.meta

    def predict(self, x, mode):
        base = self.parent.predict(x)
        return base if mode == "stable" else self.from_base(x, base, mode)

    def from_base(self, x, base, mode, fused=None):
        if mode in PROJECTED:
            center, scale, coef = self.states[mode]
            z = project(ex.transform(x, "kinetics"), mode == "type_projection")
            auxiliary = ex.softmax(6 * (rescue.design_matrix(z, center, scale) @ coef))
            return (base + auxiliary) / 2
        if fused is None:
            fused = (base + self.fusion.auxiliary(x)) / 2
        if mode == "fusion":
            return fused
        proposed = (fused.argmax(axis=1) == FOCUS) & (base.argmax(axis=1) != FOCUS)
        if not np.any(proposed):
            return fused
        rows = np.flatnonzero(proposed)
        if mode == "score_veto":
            # Strongest competing class, so the margin applies to all newly proposed positives.
            alternatives = np.delete(fused[rows], FOCUS, axis=1)
            margin = fused[rows, FOCUS] - alternatives.max(axis=1)
        elif mode == "witness_veto":
            margin = rescue.margin(x[rows], "rising_over_steady", self.states[mode])
        else:
            raise ValueError(f"unknown candidate {mode}")
        rejected = rows[margin <= 0.5]
        result = fused.copy()
        result[rejected] = base[rejected]
        return result


def score(y, probabilities):
    metrics = ex.score(y, probabilities)
    # Match the reference scorer: labels in the union of observed and predicted classes.
    present = [row["f1"] for row in metrics["per_class"].values() if row["support"] or row["predicted"]]
    metrics["macro_f1"] = float(np.mean(present))
    return metrics


def compact(metrics):
    p = metrics["per_class"]
    return {"macro_f1": metrics["macro_f1"], "accuracy": metrics["accuracy"],
            "ac_precision": p[AC]["precision"] if p[AC]["predicted"] else None,
            "ac_recall": p[AC]["recall"] if p[AC]["support"] else None, "ethanol_recall": p[ET]["recall"],
            "ac_correct": p[AC]["correct"], "ac_support": p[AC]["support"],
            "ethanol_support": p[ET]["support"], "ethanol_to_ac": metrics["confusion_matrix"][ETHANOL][FOCUS],
            "false_ac": p[AC]["predicted"] - p[AC]["correct"]}


def stress(x, case, seed):
    if case in REGULAR:
        return rescue.stress(x, case, seed)
    rng = np.random.default_rng(seed)
    s = x.reshape(-1, 16, 8).copy()
    if case == "channel_rate":
        perturb = rng.normal(0, .25, (1, 16, 6))
    else:
        tilt = {"tilt_positive": [.3, .3], "tilt_negative": [-.3, -.3], "tilt_mixed": [.3, -.3],
                "type_tilt": [.2, -.2]}[case]
        tilt = np.broadcast_to(tilt, (1, 16, 2)).copy()
        if case == "type_tilt":
            tilt += rng.normal(0, .25, (1, 4, 2))[:, rescue.GROUP]
        perturb = (tilt[..., None] * np.array([-1., 0., 1.])).reshape(1, 16, 6)
    s[:, :, 2:] *= np.exp(perturb)
    return s.reshape(-1, 128)


def calibration_counts(y, base, fused):
    proposed = (fused.argmax(axis=1) == FOCUS) & (base.argmax(axis=1) != FOCUS)
    score_ac = fused[:, FOCUS]
    pair = (y == ETHANOL) | (y == FOCUS)
    conditional = score_ac[pair] / (score_ac[pair] + fused[pair, ETHANOL])
    binary = y[pair] == FOCUS
    bins = []
    for lower, upper in SCORE_BINS:
        selected = proposed & (score_ac >= lower) & (score_ac < upper)
        bins.append((int(selected.sum()), int(np.sum(selected & (y == FOCUS))), float(score_ac[selected].sum())))
    return {"new_ac": int(proposed.sum()), "new_ac_correct": int(np.sum(proposed & (y == FOCUS))),
            "bins": bins,
            "pair_brier": float(np.mean((conditional - binary) ** 2))}


def source_study(train):
    x, y = train["x"], train["y"]
    assignment, ranges = ex.source_folds(x, y)
    expected = np.repeat([0, 1, 2, 0, 1, 2, 3, 4, 5], [84, 88, 76, 6, 10, 7, 30, 70, 74])
    if not np.array_equal(y, expected):
        raise ValueError("training receipt must refer to original ordered Batch 1")
    splits = {"group_0": assignment == 0, "group_1": assignment == 1, "month_1_reverse": np.arange(len(y)) < 248}
    rows, diagnostics = [], []
    for split, test in splits.items():
        states = fit_states(x[~test], y[~test])
        for seed in SEEDS:
            control = ex.source_control(train, ~test, seed)
            fusion = ex.Candidate.fit(control, x[~test], y[~test], "kinetics", "linear", .5)
            models = Models(fusion, states)
            cases = ("clean",) if split == "month_1_reverse" else REGULAR + CHALLENGE
            for case in cases:
                shifted, target = stress(x[test], case, seed), y[test]
                base = models.predict(shifted, "stable")
                fused = models.from_base(shifted, base, "fusion")
                values = {"stable": base, "fusion": fused}
                values.update({mode: models.from_base(shifted, base, mode, fused) for mode in MODES[2:]})
                stage = {"split": split, "seed": seed, "scenario": case}
                rows.append({**stage, "models": {mode: compact(score(target, p)) for mode, p in values.items()}})
                if split != "month_1_reverse":
                    diagnostics.append({**stage, **calibration_counts(target, base, fused)})
    return rows, ranges, diagnostics


def summarize(rows, diagnostics):
    grouped = [r for r in rows if r["split"] != "month_1_reverse"]
    summary = {}
    metrics = ("macro_f1", "ac_precision", "ac_recall", "ethanol_recall")
    for mode in MODES:
        mode_summary = {}
        for name, subset in (("all", grouped), ("regular", [r for r in grouped if r["scenario"] in REGULAR]),
                             ("challenge", [r for r in grouped if r["scenario"] in CHALLENGE]),
                             ("clean", [r for r in grouped if r["scenario"] == "clean"])):
            values = [r["models"][mode] for r in subset]
            distributions = {key: [v[key] for v in values if v[key] is not None] for key in metrics}
            worst = min(subset, key=lambda r: r["models"][mode]["macro_f1"])
            mode_summary[name] = {
                "mean": {k: float(np.mean(v)) if v else None for k, v in distributions.items()},
                "worst": {k: min(v) if v else None for k, v in distributions.items()},
                "worst_macro_stage": {k: worst[k] for k in ("split", "seed", "scenario")},
                "no_ac_predictions_stages": sum(v["ac_precision"] is None for v in values),
                "ethanol_to_ac": sum(v["ethanol_to_ac"] for v in values),
            }
        # Each case+seed visits all 30 source Ac and 90 source Et exactly once.
        mode_summary["two_group_count_ranges"] = {}
        for case in REGULAR + CHALLENGE:
            totals = [[sum(r["models"][mode][key] for r in grouped if r["seed"] == seed and r["scenario"] == case)
                       for seed in SEEDS] for key in ("ac_correct", "ethanol_to_ac")]
            mode_summary["two_group_count_ranges"][case] = {
                "ac_correct_of_30": [min(totals[0]), max(totals[0])],
                "ethanol_to_ac_of_90": [min(totals[1]), max(totals[1])],
            }
        month = [r["models"][mode] for r in rows if r["split"] == "month_1_reverse"]
        mode_summary["month_1_reverse"] = {k: [min(v[k] for v in month), max(v[k] for v in month)]
                                            for k in ("accuracy", "ethanol_recall", "ethanol_to_ac", "false_ac")}
        summary[mode] = mode_summary

    calibration = {}
    for case in REGULAR + CHALLENGE:
        subset = [r for r in diagnostics if r["scenario"] == case]
        counts = {key: sum(r[key] for r in subset) for key in ("new_ac", "new_ac_correct")}
        bins = []
        for bounds, values in zip(SCORE_BINS, zip(*(r["bins"] for r in subset))):
            count, correct, score_sum = map(sum, zip(*values))
            if count:
                bins.append({"score_range": [bounds[0], min(bounds[1], 1.)], "predictions": count,
                             "true_ac": correct, "mean_score": score_sum / count})
        calibration[case] = {**counts, "new_ac_score_bins": bins,
                             "mean_ethanol_ac_pair_brier": float(np.mean([r["pair_brier"] for r in subset]))}
    return summary, calibration


def shortlist(summary):
    """Local research criteria fixed before study, with no-update as a candidate."""
    fusion = summary["fusion"]
    stable = summary["stable"]
    reviews = {}
    for mode in MODES[2:]:
        entry = summary[mode]
        checks = {
            "reduces_ethanol_to_ac": entry["all"]["ethanol_to_ac"] < fusion["all"]["ethanol_to_ac"],
            "retains_mean_ac_recall_within_5pp": entry["all"]["mean"]["ac_recall"] >= fusion["all"]["mean"]["ac_recall"] - .05,
            "retains_clean_ethanol_recall_within_3pp": entry["clean"]["mean"]["ethanol_recall"] >= fusion["clean"]["mean"]["ethanol_recall"] - .03,
            "no_worse_challenge_macro_floor_than_stable": entry["challenge"]["worst"]["macro_f1"] >= stable["challenge"]["worst"]["macro_f1"],
            "no_worse_month_ethanol_to_ac_max_than_fusion": entry["month_1_reverse"]["ethanol_to_ac"][1] <= fusion["month_1_reverse"]["ethanol_to_ac"][1],
        }
        reviews[mode] = {"passed": all(checks.values()), "failed_checks": [k for k, passed in checks.items() if not passed]}
    eligible = [mode for mode in reviews if reviews[mode]["passed"]]
    preferred = max(eligible, key=lambda mode: summary[mode]["all"]["mean"]["macro_f1"], default=None)
    return {"preferred_for_independent_evaluation": preferred, "criteria": reviews}


def benchmark(models, x):
    results = {}
    for mode in MODES:
        models.predict(x, mode)
        start = process_time()
        for _ in range(100):
            models.predict(x, mode)
        results[mode] = {"cpu_ms_per_batch": (process_time() - start) * 10, "batch_rows": len(x),
                         "mlp_forwards_per_batch": 1, "extra_linear_heads_max": int(mode != "stable") + int(mode == "witness_veto"),
                         "llm_calls": 0, "llm_tokens": 0}
    return results


def read_receipt(path, fusion_path, parent_path):
    receipt = ex.json_value(path.read_text(encoding="utf-8"))
    if (receipt["format"] != ex.VERSION or receipt["candidate_sha256"] != checkpoint_digest(fusion_path)
            or receipt["parent_checkpoint_sha256"] != checkpoint_digest(parent_path)):
        raise ValueError("round 01 receipt does not match both checkpoints")
    return receipt


def load_fusion(fusion_path, parent_path):
    fusion = ex.Candidate.load(fusion_path, parent_path)
    if (fusion.view, fusion.method, fusion.weight) != ("kinetics", "linear", .5) or fusion.meta["classes"] != CLASSES:
        raise ValueError("expected the round 01 kinetics/linear fusion and Task A label order")
    return fusion


def load_parent(path):
    model = Model.load(path)
    if model.meta["task"] != "classification" or model.meta["classes"] != CLASSES or len(model.meta["paths"]) != 128:
        raise ValueError("expected a Task A checkpoint")
    return model


def read_source(path, receipt, paths):
    if checkpoint_digest(path) != receipt["train_sha256"]:
        raise ValueError("source study requires the exact Batch 1 data bound by the round 01 receipt")
    train = read_dataset(path, "classification", CLASSES, paths)
    if train["sha256"] != receipt["train_sha256"]:
        raise ValueError("training data changed during the read")
    return train


def implementation_digests():
    files = [Path(__file__), Path(ex.__file__), Path(rescue.__file__), Path(rollout.__file__), Path(__file__).with_name("decision.py")]
    return {path.name: checkpoint_digest(path) for path in files}


def state_payload(states, receipt):
    return {"version": VERSION, "fusion_sha256": receipt["candidate_sha256"],
            "parent_sha256": receipt["parent_checkpoint_sha256"], "train_sha256": receipt["train_sha256"],
            **{f"{mode}_{field}": value for mode, state in states.items()
               for field, value in zip(("center", "scale", "coef"), state)}}


def load_states(path, report_path, fusion_path, parent_path, train_digest):
    report = ex.json_value(report_path.read_text(encoding="utf-8"))
    if (report["version"] != VERSION or report["state_sha256"] != checkpoint_digest(path)
            or report["code_sha256"] != implementation_digests()):
        raise ValueError("study report does not match the candidate state or code")
    with np.load(path, allow_pickle=False) as data:
        if (str(data["version"]) != VERSION or str(data["fusion_sha256"]) != checkpoint_digest(fusion_path)
                or str(data["parent_sha256"]) != checkpoint_digest(parent_path)
                or str(data["train_sha256"]) != report["receipts"]["train_sha256"]
                or (train_digest is not None and str(data["train_sha256"]) != train_digest)):
            raise ValueError("study state does not match the fusion, parent or training digest")
        return {mode: tuple(data[f"{mode}_{field}"] for field in ("center", "scale", "coef"))
                for mode in ("witness_veto", *PROJECTED)}


def study(args):
    if args.output.exists():
        raise FileExistsError(args.output)
    receipt = read_receipt(args.receipt, args.fusion, args.incumbent)
    fusion = load_fusion(args.fusion, args.incumbent)
    train = read_source(args.train, receipt, fusion.meta["paths"])
    started, cpu = perf_counter(), process_time()
    stages, groups, diagnostics = source_study(train)
    summary, calibration = summarize(stages, diagnostics)
    selection = shortlist(summary)
    study_wall, study_cpu = perf_counter() - started, process_time() - cpu
    states = fit_states(train["x"], train["y"])
    fit_cost = {}
    for mode in ("witness_veto", *PROJECTED):
        start = process_time()
        for _ in range(20):
            if mode == "witness_veto":
                rescue.fit_binary(train["x"], train["y"], "rising_over_steady", 1.)
            else:
                fit_projection(train["x"], train["y"], mode)
        fit_cost[mode] = (process_time() - start) * 50
    reference = selection["preferred_for_independent_evaluation"]
    agent = {"decision": "keep", "active_model": "stable", "evidence": "source_holdout",
             "reason": "independent_evaluation_required" if reference else "no_candidate_passed_source_checks",
             "preferred_for_independent_evaluation": reference,
             "failed_check_counts": {name: len(v["failed_checks"]) for name, v in selection["criteria"].items()},
             "llm_calls": 0}
    report = {"version": VERSION, "evaluation_scope": "batch_1_grouped_and_synthetic_only",
              "competition_metric": {"primary": "macro_f1", "auxiliary": "accuracy", "official_score": None},
              "receipts": {k: receipt[k] for k in ("train_sha256", "candidate_sha256", "parent_checkpoint_sha256")},
              "code_sha256": implementation_digests(), "python": platform.python_version(), "numpy": np.__version__,
              "seeds": SEEDS, "regular_scenarios": REGULAR, "challenge_scenarios": CHALLENGE, "groups": groups,
              "summary": summary, "selection": selection, "calibration": calibration, "stages": stages,
              "cpu": {"study_seconds": study_cpu, "study_wall_seconds": study_wall, "added_fit_ms": fit_cost,
                      "inference": benchmark(Models(fusion, states), train["x"])}, "agent_summary": agent}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".a-study-", dir=args.output.parent) as temporary:
        staging = Path(temporary) / "result"
        staging.mkdir()
        state_file = staging / "study_state.npz"
        np.savez_compressed(state_file, **state_payload(states, receipt))
        report["state_sha256"] = checkpoint_digest(state_file)
        ex.save_json(staging / "study.json", report)
        if args.output.exists():
            raise FileExistsError(args.output)
        staging.rename(args.output)
    print(json.dumps(agent, ensure_ascii=False))


def review_run(args):
    thresholds = ex.json_value(args.policy.read_text(encoding="utf-8")) if args.policy else None
    candidate_name = None if args.variant == "stable" else args.variant
    if candidate_name is None or args.evaluation is None:
        load_parent(args.incumbent)
        result = assess(None, {candidate_name: None} if candidate_name else {}, evidence="unavailable", thresholds=thresholds)
    else:
        receipt = read_receipt(args.receipt, args.fusion, args.incumbent)
        fusion = load_fusion(args.fusion, args.incumbent)
        train = read_source(args.train, receipt, fusion.meta["paths"])
        if args.evidence == "independent_released" and not (args.release_id or "").strip():
            raise ValueError("independent evaluation requires an explicit release identifier")
        data = read_dataset(args.evaluation, "classification", CLASSES, fusion.meta["paths"])
        if args.evidence == "independent_released" and (data["sha256"] == PUBLIC_EVALUATION or
                any(identity.startswith("gas_b02_") for identity in data["ids"])):
            raise ValueError("public Batch 2 is development evidence")
        if set(train["ids"]) & set(data["ids"]) or set(map(tuple, train["x"])) & set(map(tuple, data["x"])):
            raise ValueError("training and evaluation rows overlap")
        model = models_for(args, fusion, train["sha256"])
        old, new = (score(data["y"], model.predict(data["x"], mode)) for mode in ("stable", candidate_name))
        result = assess(old, {candidate_name: new}, evidence=args.evidence, thresholds=thresholds)
        result["evaluation"] = {"sha256": data["sha256"], "rows": len(data["y"]), "release_id": args.release_id}
        result["per_class_and_confusion"] = {"stable": old, candidate_name: new}
    result["active_model"] = result["selected_candidate"] or "stable"
    result["incumbent_sha256"] = checkpoint_digest(args.incumbent)
    result["incumbent_checkpoint"] = str(args.incumbent.resolve())
    if result["selected_candidate"]:
        result["selected_model_artifacts"] = {"fusion": str(args.fusion.resolve()), "fusion_sha256": checkpoint_digest(args.fusion)}
        if candidate_name in ("witness_veto", *PROJECTED):
            result["selected_model_artifacts"].update(state=str(args.state.resolve()), state_sha256=checkpoint_digest(args.state),
                                                      study_report=str(args.study_report.resolve()))
    result["agent_summary"]["active_model"] = result["active_model"]
    if args.output:
        ex.save_json(args.output, result)
    print(json.dumps(result["agent_summary"], ensure_ascii=False))


def models_for(args, fusion, train_digest=None):
    needs_state = args.variant in ("witness_veto", *PROJECTED)
    if needs_state and not (args.state and args.study_report):
        raise ValueError(f"--state and --study-report are required for {args.variant}")
    states = load_states(args.state, args.study_report, args.fusion, args.incumbent, train_digest) if needs_state else {}
    return Models(fusion, states)


def predict_requests(args):
    if args.variant == "stable":
        predictor = load_parent(args.incumbent)
    else:
        model = models_for(args, load_fusion(args.fusion, args.incumbent))
        predictor = SimpleNamespace(meta=model.meta, predict=lambda x: model.predict(x, args.variant))
    for line in sys.stdin:
        if not line.strip():
            continue
        request = ex.json_value(line)
        if (not isinstance(request, dict) or set(request) - {"task", "inputs"} or "inputs" not in request
                or request.get("task", "classification") != "classification"):
            raise ValueError("classification prediction requires inputs and accepts optional task")
        result = ex.format_prediction(predictor, request["inputs"])
        print(json.dumps(result, allow_nan=False), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="action", required=True)
    study_parser = commands.add_parser("study", help="fit and score grouped Batch 1 only")
    predict_parser = commands.add_parser("predict", help="predict one JSONL request at a time")
    review_parser = commands.add_parser("review", help="review one fixed challenger, with no-update support")
    for command in (study_parser, predict_parser, review_parser):
        command.add_argument("--incumbent", type=Path, required=True)
        command.add_argument("--fusion", type=Path, required=command is study_parser)
    for command in (study_parser, review_parser):
        for name in ("train", "receipt", "output"):
            command.add_argument(f"--{name}", type=Path, required=command is study_parser)
    for command in (predict_parser, review_parser):
        command.add_argument("--state", type=Path)
        command.add_argument("--study-report", type=Path)
        command.add_argument("--variant", choices=MODES, default="stable")
    review_parser.add_argument("--evaluation", type=Path)
    review_parser.add_argument("--evidence", choices=("public_development", "independent_released"), default="public_development")
    review_parser.add_argument("--release-id")
    review_parser.add_argument("--policy", type=Path)
    args = parser.parse_args()
    if args.action == "predict" and args.variant != "stable" and args.fusion is None:
        parser.error("non-stable prediction requires --fusion")
    if args.action == "review" and args.variant != "stable" and args.evaluation and not all((args.train, args.receipt, args.fusion)):
        parser.error("paired review requires --train, --receipt and --fusion")
    {"study": study, "predict": predict_requests, "review": review_run}[args.action](args)


if __name__ == "__main__":
    main()
