# 提交清单与填写指引

**赛题**：“智训引擎”——工业制造场景下的模型训练与超参数优化
**队伍**：gy_65511　**版本**：v8　**整理日期**：2026-11-24

---

## 一、平台表单逐字段填写

> 平台的「提交材料」原文：
> 「镜像和源码、模型调用信息、实验记录链接，以及设计说明、技术报告（不超过 10 页）、
> 演示视频（不超过 5 分钟）和来源声明。**平台没有单独入口的材料请随作品文档提交
> 或提供链接。**」

| # | 表单字段 | 填写内容 | 本包中的文件 |
|---|---|---|---|
| 1 | **模型类型** | `持久化 Sampler 微调权重`（sampler） | — |
| 2 | **模型 / 权重路径** | `trio://run_7yqgoj5be2n0/sampler_weights/planner-27b-sft-v1` | `01_模型配置/模型配置.txt` §一 |
| 3 | **作品文档**（唯一文件入口） | 上传 `01_模型配置/作品文档.txt`（57.8 KB） | `01_模型配置/作品文档.txt` |
| 4 | **已选择的 Harness 镜像** | `1c1c15536e00d43d129e7457fbb905b1`（上传 `02_Harness系统镜像/zhixun-engine-linux-amd64.tar`）| `02_Harness系统镜像/` |
| 5 | **源码仓库链接** | `https://github.com/GY-phd/ai-` | `06_源码与依赖/` |
| 6 | **训练记录链接**（实验记录） | `https://raw.githubusercontent.com/GY-phd/ai-/main/runs/harness-offline/run_report.json` | `03_云端实验记录/run_report.json` |
| 7 | **PyTRiO API Key** | 只填在密钥栏，**不写入任何文件** | — |

> **作品文档**这一个文件同时承载了规则表里另外几项（因为平台没有单独入口）：
> 设计说明、技术报告、演示视频说明、来源声明、云端实验记录查询依据。
> 全部合并在 `作品文档.txt` 的第 2–7 节。

---

## 二、规则表逐条对应（截图第 34–40 行）

| 规则行 | 要求 | 本包交付物 | 大小 | 合规 |
|---|---|---|---|---|
| 34 | 模型配置（txt，≤50M） | `01_模型配置/作品文档.txt` | 57.8 KB | ✅（平台前端实际限 2 MiB） |
| 35 | Harness 的系统镜像（tar，≤50M，超出用网盘链接） | `02_Harness系统镜像/zhixun-engine-linux-amd64.tar` | 174.3 MiB | ⚠️ 见 §四 |
| 36 | 云端实验记录链接或查询依据（pdf/txt ≤10M，或本机 <100 字） | `03_云端实验记录/`（链接 + 99 字备选 + 全文 + 账本 + SwanLab） | 44.6 KB + 26 KB + 36 KB | ✅ |
| 37 | 系统运行说明文档（pdf，≤10M） | `04_系统运行说明文档/系统运行说明文档.pdf` | 236 KB | ✅ |
| 38 | 项目说明书（pdf，≤10M） | `05_项目说明书/项目说明书.pdf` | 278 KB | ✅ |
| 39 | 答辩 PPT（pptx，≤10M） | `07_答辩PPT内容大纲/答辩PPT内容大纲.md`（16 页大纲 + 口播稿 + 备份页） | 18.3 KB | 📄 待制作 |
| 40 | 项目源代码（zip，≤50M）+ 依赖清单 + 配置文件 | `06_源码与依赖/智训引擎-源码包-v8.zip`（359 文件） | 2.30 MiB | ✅ |

**平台另有三项没有单独表格行、但规则文字明确要求的材料**，已放进作品文档：

| 平台规则要求 | 本包交付物 | 所在位置 |
|---|---|---|
| **设计说明** | 项目说明书正文 | `作品文档.txt` 第 2 节 |
| **技术报告**（≤10 页） | 技术报告（**5 页**） | `作品文档.txt` 第 3 节 + `09_技术报告与附件/技术报告.pdf` |
| **演示视频**（≤5 分钟） | 完整分镜脚本（4 分 30 秒） | `作品文档.txt` 第 4 节 + `09_技术报告与附件/演示视频脚本.md` |
| **来源声明** | 来源声明 | `作品文档.txt` 第 5 节 + `09_技术报告与附件/来源声明.md` |

---

## 三、镜像校验（提交前必须核对）

```
文件: 02_Harness系统镜像/zhixun-engine-linux-amd64.tar
大小: 182,732,800 字节 (174.27 MiB)
SHA256: ffc64b8e95e7d98ddeae37f186c27cee6236efe18d5c0f3b89e4b3982abf03eb
平台归档 ID: 1c1c15536e00d43d129e7457fbb905b1
```

核对命令：

```powershell
Get-FileHash "提交材料_20261125\02_Harness系统镜像\zhixun-engine-linux-amd64.tar" -Algorithm SHA256
```

> ⚠️ **不要重新构建镜像**。当前这个 tar 已经在平台上传成功并被两次试运行
> 使用过（`status: ready`），重新构建会产生不同的字节。
> 若必须重建，务必用
> `python tools/build_docker_image.py --out zhixun-engine-linux-amd64.tar`
> 再跑 `--verify-only` 与 `tools/verify_image_roundtrip.py`。

---

## 四、⚠️ 镜像大小与网盘链接（唯一需要注意的一项）

**规则表第 35 行**：「Harness 的系统镜像（格式为 tar，不大于 50M，超出 50MB 时，
上传网盘链接。）」

**实际情况**：

| 事实 | 来源 |
|---|---|
| 我们的 tar 是 174.27 MiB，**超过 50M** | `Get-Item` |
| 平台前端**没有**对镜像大小做客户端校验 | `tools/read_platform_limits.py` 读平台 bundle |
| 平台**已成功接收**该归档，`status: ready` | `/api/v1/image-archives` → `1c1c1553…` |
| 该归档已被两次试运行实际使用 | 运行记录 v8 两次 |

**结论**：平台实际上传路径可用（已验证）。但为符合规则文字，**必须同时准备
一个网盘链接**，写在《作品文档》第 1 节：

```
网盘链接: https://pan.baidu.com/s/1____________________  提取码: ____
  文件  : zhixun-engine-linux-amd64.tar
  大小  : 182,732,800 字节 (174.27 MiB)
  SHA256: ffc64b8e95e7d98ddeae37f186c27cee6236efe18d5c0f3b89e4b3982abf03eb
  平台归档 ID: 1c1c15536e00d43d129e7457fbb905b1
```

**完整操作步骤、校验命令、答辩口播稿见** → `02_Harness系统镜像/百度网盘链接_上传与填写指引.md`

**上传后需要做的 3 件事**：

1. 把分享链接与提取码填进 `01_模型配置/模型配置.txt` 的「网盘链接」那一行
   （当前是占位符 `https://pan.baidu.com/s/1____________________`）
2. 重新生成作品文档：
   ```powershell
   python tools/build_works_document.py
   ```
3. 核对体积 ≤ 2 MiB，然后上传 `01_模型配置/作品文档.txt` 到平台

> ⚠️ **不要重新构建镜像。** 当前这个 tar 已经被平台接收并跑过两次试运行
> （A、B 各 10 轮全部成功），重新构建会产生不同的字节，破坏可复现性。

**减小镜像的可行性**（若平台后续收紧限制）：

| 方案 | 预估体积 | 风险 |
|---|---:|---|
| A. `python:3.12-alpine` + numpy | ~45–55 MB | musl 与 numpy ABI 需重验；**OpenBLAS 线程行为改变浮点归约顺序 ⇒ 结果不可复现** |
| B. 静态链接 numpy 的 manylinux wheel | ~70–90 MB | 仍带 slim 基础层 77 MB，**降不到 50 MB** |
| C. 精简 slim 基础层 | ~130 MB | 收益有限但仍超 50 MB |

**镜像体积实测构成**（说明为什么减不动）：

| Layer | 大小 | 内容 |
|---|---:|---|
| `sha256-37fb86c2…` | 77.5 MB | `python:3.12-slim` 基础层 |
| `zhixun-engine-deps` | 55.9 MB | numpy 28.2 + numpy.libs 26.8 MB |
| `sha256-2dc99d2d…` | 36.4 MB | 基础层依赖 |
| `sha256-68bced9e…` | 3.9 MB | 系统文件 |
| **`zhixun-engine`（我们的代码）** | **0.5 MB** | **全部参赛实现** |

> **我们自己的代码只有 0.5 MB**，174 MB 里 99.7% 是 Python 运行时和 numpy。
> 减重的唯一有效路径是换基础镜像，而那会牺牲数值可复现性。
> **在当前镜像已被平台成功接收并跑通 A/B 各 10 轮的前提下，不建议为此改动。**

---

## 五、⚠️ 提交前必须做的两件事（平台状态）

### 5.1 把正式选中的提交切到 v8

平台当前状态（2026-11-24 21:00 读取）：

| 版本 | 提交 ID | 状态 | **正式选中** | 绑定镜像 | training_url |
|---|---|---|---|---|---|
| v8 | `620b3c3a…` | valid | ❌ | `1c1c1553…` ✅ | `run_report.json` ✅ |
| v7 | `542ab56d…` | draft | ❌ | `1c1c1553…` ✅ | `run_report.json` ✅ |
| v6 | `016ab938…` | valid | ❌ | `24d8e85c…` | `run_report.json` ✅ |
| **v5** | `68043bfd…` | valid | **✅** | **`58cc7f50…`（62.2 MiB 老包）** | **`PLANNER_SFT_RECORD.md`** |

> **正式选中的仍是 v5，绑的是 11-22 的老镜像**——那个包跑出来 C 方向
> 56.25329，劣于基线 10.06%。
>
> **不切到 v8，正式评测跑的就是没有根因修复的旧镜像。**

操作：平台「提交方案」页 → 找到 v8（`620b3c3a…`）→ 点 **「选为正式版本」**
（前端按钮文案；对应 `POST /api/v1/submissions/{id}/select`）。
v8 的 `status` 为 `valid` 且 `image_archive_id` 已填，具备切换条件。

> 注：平台还有一条 `draft` 状态的 v7 绑着同一个镜像。切之前确认最终采纳的是
> `620b3c3a…`（v8，`status: valid`）。

### 5.2 复核 sampler 路径是否仍可调用

本地用同一把 API Key 直接探测：

| 探测 | 结果 |
|---|---|
| `get_server_capabilities()` | ✅ 正常 |
| 基础模型 `Qwen/Qwen3.8-27B` | ✅ 能采样，但 64 token 需 **141.6 ~ 825.4 秒** |
| **`trio://run_7yqgoj5be2n0/sampler_weights/planner-27b-sft-v1`** | ❌ **404 `model_not_found`** |

**若该路径确实不可用了**，按《平台提交表单填写指南》的预案改选「基础模型」
（`Qwen/Qwen3.8-27B`），并在表单与作品文档中**如实说明未使用微调权重**。
基础模型同样符合赛题要求（平台原文：「可使用微调后的 Sampler，
**或提交页允许的官方基础模型**」）。

---

## 六、平台额度与运行状态

| 项 | 状态（2026-11-24 21:00） |
|---|---|
| **正式评测** | **已用 0 / 3，剩余 3 次** |
| 试运行 | 已用 5 / 8 |
| `formal_ready` | `true`，`blockers: []` |
| 最近两次 v8 试运行 | 均因**上游模型网关 HTTP 504** 失败（平台侧问题，A/B 各 10 轮全跑通） |

> **正式评测的 3 次额度要留到上游稳定时用。** 试运行失败不消耗正式额度，
> 但正式评测期间失败会浪费一次。

---

## 七、本包的完整文件树

```
提交材料_20261125/
├── README.md                              ← 本文件
├── 01_模型配置/
│   ├── 作品文档.txt                        ★ 平台唯一文件入口 (57.8 KB)
│   └── 模型配置.txt                        单独的模型配置 (8.1 KB)
├── 02_Harness系统镜像/
│   ├── zhixun-engine-linux-amd64.tar       ★ 平台镜像 (174.27 MiB)
│   ├── zhixun-engine-linux-amd64.tar.sha256
│   └── 百度网盘链接_上传与填写指引.md      ★ 镜像 >50M 的网盘链接填写步骤
├── 03_云端实验记录/
│   ├── 云端实验记录说明.md                 链接 + 99 字备选 + 查询依据
│   ├── run_report.json                    3 方向 × 10 轮汇总
│   ├── ledger.jsonl                       30 轮逐轮账本
│   └── swanlab/                           30 个 SwanLab 逐轮记录
├── 04_系统运行说明文档/
│   └── 系统运行说明文档.pdf                ★ (236 KB, 4 页)
├── 05_项目说明书/
│   └── 项目说明书.pdf                      ★ (278 KB, 5 页)
├── 06_源码与依赖/
│   ├── 智训引擎-源码包-v8.zip              ★ (2.30 MiB, 359 文件)
│   ├── requirements.txt / requirements-dev.txt
│   ├── Dockerfile / LICENSE / MANIFEST.json
├── 07_答辩PPT内容大纲/
│   └── 答辩PPT内容大纲.md                  ★ 16 页大纲 + 口播稿 + 备份页
├── 08_技术成果与系统总结/
│   └── 最新技术成果与技术总览.md          ★ 系统全部技术成果与创新点汇总
└── 09_技术报告与附件/
    ├── 技术报告.pdf                        ★ (264 KB, 5 页 ≤ 10 页)
    ├── 技术报告_正文.md
    ├── 演示视频脚本.md                      4 分 30 秒分镜
    ├── 来源声明.md
    └── 平台规则与评分要点.md                从平台代码读出的规则与评分构成
```

> **08_技术成果与系统总结** 是给评审与接手者的**单文件全量说明**：
> 系统架构 → C 方向根因定位与修复 → epoch 预算再标定 → 相对退化度加权 →
> 27B LoRA 决策层 → 三重实验记录 → 安全与工业适配 → 平台实测与失败诊断
> → 镜像体积分析 → 技术债与边界。每条结论都附具体证据文件路径。

---

## 八、生成与校验

本包由以下脚本生成，可重复执行：

```powershell
python tools/build_submission_pdfs.py       # 两份 PDF + 技术报告
python tools/build_source_archive.py        # 源码 zip
python tools/build_works_document.py        # 作品文档（合并 7 节）
python tools/read_platform_limits.py        # 读平台 bundle 的限制（用于复核）
```

一致性校验：

```powershell
# 1. 镜像摘要
Get-FileHash "提交材料_20261125\02_Harness系统镜像\zhixun-engine-linux-amd64.tar" -Algorithm SHA256

# 2. 源码包内容与仓库一致
python -c "import zipfile;z=zipfile.ZipFile(r'提交材料_20261125/06_源码与依赖/智训引擎-源码包-v8.zip');print(len(z.namelist()),'files');print([n for n in z.namelist() if n.endswith('profile_c.py')])"

# 3. 作品文档体积
python -c "import os;print(os.path.getsize(r'提交材料_20261125/01_模型配置/作品文档.txt'),'bytes')"

# 4. 测试套件
python -m pytest -q
```
